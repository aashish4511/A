"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { ShoppingBag, Menu, X, Check } from "lucide-react";
import { useCart } from "@/components/cart";
import { inr, UPI_ID, upiUri } from "@/lib/format";

export type ProductCardData = {
  id: number;
  slug: string;
  name: string;
  tagline: string;
  category: string;
  image: string;
  price: number;
  mrp: number;
  stock: number;
};

/* ---------------- reveal ---------------- */

export function Reveal({
  children,
  delay = 0,
  className = "",
  as: Tag = "div",
}: {
  children: React.ReactNode;
  delay?: number;
  className?: string;
  as?: React.ElementType;
}) {
  const ref = useRef<HTMLElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            el.classList.add("is-in");
            io.unobserve(el);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -6% 0px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <Tag ref={ref} className={`reveal ${className}`} style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </Tag>
  );
}

export function Rule({ className = "" }: { className?: string }) {
  return (
    <div className={`h-px w-full origin-left bg-ink/15 ${className}`}>
      <div className="drawline h-px w-full bg-ink/25" />
    </div>
  );
}

/* ---------------- chrome ---------------- */

export function Spine() {
  return (
    <div className="pointer-events-none fixed inset-y-0 left-0 z-40 hidden w-16 border-r border-ink/12 bg-paper lg:block">
      <div className="flex h-full flex-col items-center justify-between py-6">
        <div className="h-10 w-px bg-brass" />
        <div
          className="label whitespace-nowrap text-ink/55"
          style={{ writingMode: "vertical-rl", transform: "rotate(180deg)" }}
        >
          FORM &amp; FIELD · THE EVERYDAY EDIT · INDIA
        </div>
        <div className="h-10 w-px bg-brass" />
      </div>
    </div>
  );
}

const NAV = [
  { href: "/shop", label: "Shop all" },
  { href: "/shop?category=Watches", label: "Watches" },
  { href: "/shop?category=Perfumes", label: "Perfumes" },
  { href: "/shop?category=Men%27s%20Wear", label: "Men" },
  { href: "/shop?category=Women%27s%20Wear", label: "Women" },
];

export function Header() {
  const { count } = useCart();
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50">
      <div className="hidden bg-ink text-paper md:block">
        <div className="mx-auto flex max-w-[1400px] items-center justify-between px-6 py-2 lg:px-12">
          <p className="label text-paper/70">
            Free shipping across India above ₹2,500 · Cash on Delivery &amp; UPI
          </p>
          <p className="label text-brass-2">
            Pay by UPI: <span className="tnum">{UPI_ID}</span>
          </p>
        </div>
      </div>
      <div className="border-b border-ink/12 bg-paper/92 backdrop-blur-sm">
        <div className="mx-auto flex max-w-[1400px] items-center justify-between px-6 py-4 lg:px-12">
          <Link href="/" className="group flex items-baseline gap-3">
            <span className="display text-2xl font-semibold tracking-tight text-ink sm:text-[28px]">
              FORM <span className="italic font-light text-brass">&amp;</span> FIELD
            </span>
            <span className="label hidden text-stone sm:inline">The everyday edit</span>
          </Link>

          <nav className="hidden items-center gap-7 xl:gap-8 md:flex">
            {NAV.map((n) => (
              <Link
                key={n.label}
                href={n.href}
                className="label whitespace-nowrap text-ink/70 transition-colors hover:text-brass"
              >
                {n.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <Link
              href="/cart"
              className="group relative flex items-center gap-2 border border-ink/25 px-4 py-2 text-ink transition-colors hover:border-brass hover:text-brass"
            >
              <ShoppingBag className="h-4 w-4" strokeWidth={1.5} />
              <span className="label">Cart</span>
              <span className="tnum label ml-1 min-w-5 bg-ink px-1.5 py-0.5 text-center text-[10px] text-paper group-hover:bg-brass">
                {count}
              </span>
            </Link>
            <button
              aria-label="Menu"
              onClick={() => setOpen((v) => !v)}
              className="border border-ink/25 p-2.5 md:hidden"
            >
              {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </button>
          </div>
        </div>
        {open && (
          <div className="border-t border-ink/12 px-6 pb-5 pt-3 md:hidden">
            {NAV.map((n) => (
              <Link
                key={n.label}
                href={n.href}
                onClick={() => setOpen(false)}
                className="label block border-b border-ink/10 py-3 text-ink/75"
              >
                {n.label}
              </Link>
            ))}
            <Link href="/admin/login" className="label block py-3 text-brass">
              Admin sign in
            </Link>
          </div>
        )}
      </div>
    </header>
  );
}

export function Footer() {
  return (
    <footer className="mt-24 bg-ink text-paper">
      <div className="mx-auto max-w-[1400px] px-6 py-16 lg:px-12">
        <div className="grid gap-12 md:grid-cols-[1.4fr_1fr_1fr_1.1fr]">
          <div>
            <p className="display text-4xl leading-none">
              FORM <span className="italic font-light text-brass-2">&amp;</span> FIELD
            </p>
            <p className="mt-5 max-w-xs text-sm leading-relaxed text-paper/65">
              Watches with a point of view, fragrances that feel like yours, and clothes you reach
              for on repeat. A considered everyday edit, delivered across India.
            </p>
          </div>
          <div>
            <p className="label text-brass-2">Shop</p>
            <ul className="mt-4 space-y-2.5 text-sm text-paper/70">
              <li><Link className="hover:text-brass-2" href="/shop">Shop all</Link></li>
              <li><Link className="hover:text-brass-2" href="/shop?category=Watches">Watches</Link></li>
              <li><Link className="hover:text-brass-2" href="/shop?category=Perfumes">Perfumes</Link></li>
              <li><Link className="hover:text-brass-2" href="/shop?category=Men%27s%20Wear">Men&apos;s wear</Link></li>
              <li><Link className="hover:text-brass-2" href="/shop?category=Women%27s%20Wear">Women&apos;s wear</Link></li>
            </ul>
          </div>
          <div>
            <p className="label text-brass-2">Help</p>
            <ul className="mt-4 space-y-2.5 text-sm text-paper/70">
              <li>7-day replacement</li>
              <li>Cash on Delivery</li>
              <li>UPI &amp; QR payment</li>
              <li>Shipping across India</li>
            </ul>
          </div>
          <div>
            <p className="label text-brass-2">Order support</p>
            <p className="mt-4 text-sm leading-relaxed text-paper/70">
              Online store · shipping across India
              <br />
              Cash on Delivery or UPI
              <br />
              <span className="tnum">UPI · 9067794355@fam</span>
            </p>
            <Link
              href="/admin/login"
              className="label mt-5 inline-block border border-paper/25 px-4 py-2 text-paper/80 hover:border-brass-2 hover:text-brass-2"
            >
              Owner login
            </Link>
          </div>
        </div>
        <div className="mt-14 flex flex-col gap-3 border-t border-paper/15 pt-6 text-paper/45 md:flex-row md:items-center md:justify-between">
          <p className="label">© {new Date().getFullYear()} FORM &amp; FIELD · THE EVERYDAY EDIT</p>
          <p className="label">Watches · Fragrance · Men&apos;s &amp; Women&apos;s Wear</p>
        </div>
      </div>
    </footer>
  );
}

/* ---------------- product ---------------- */

export function AddToCart({
  product,
  qty = 1,
  full = false,
  label = "Add to cart",
}: {
  product: ProductCardData;
  qty?: number;
  full?: boolean;
  label?: string;
}) {
  const { add } = useCart();
  const [done, setDone] = useState(false);
  const soldOut = product.stock <= 0;
  return (
    <button
      disabled={soldOut}
      onClick={() => {
        if (soldOut) return;
        add(product, qty);
        setDone(true);
        window.setTimeout(() => setDone(false), 1600);
      }}
      className={`group inline-flex items-center justify-center gap-2.5 px-7 py-4 transition-colors ${
        full ? "w-full" : ""
      } ${
        soldOut
          ? "cursor-not-allowed bg-ink/35 text-paper/60"
          : done
            ? "bg-brass text-ink-3"
            : "bg-ink text-paper hover:bg-brass hover:text-ink-3"
      }`}
    >
      {done ? <Check className="h-4 w-4" strokeWidth={2} /> : null}
      <span className="label">{soldOut ? "Sold out" : done ? "Added to cart" : label}</span>
    </button>
  );
}

export function ProductCard({ product, index = 0 }: { product: ProductCardData; index?: number }) {
  const off = product.mrp > product.price ? Math.round((1 - product.price / product.mrp) * 100) : 0;
  const apparel = product.category === "Men's Wear" || product.category === "Women's Wear";
  return (
    <Reveal delay={(index % 3) * 90} className="group">
      <Link href={`/product/${product.slug}`} className="block">
        <div className="sweep relative aspect-[4/5] overflow-hidden bg-ink/8">
          <img
            src={product.image}
            alt={product.name}
            className="h-full w-full object-cover transition-transform duration-[900ms] ease-out group-hover:scale-[1.04]"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink/45 via-transparent to-transparent" />
          {off > 0 && (
            <span className="label absolute left-0 top-4 bg-vermillion px-3 py-1.5 text-paper">
              {off}% off
            </span>
          )}
          {product.stock <= 6 && product.stock > 0 && (
            <span className="label absolute right-0 top-4 bg-paper/95 px-3 py-1.5 text-ink">
              Only {product.stock} left
            </span>
          )}
          {product.stock <= 0 && (
            <span className="label absolute right-0 top-4 bg-ink px-3 py-1.5 text-paper">
              Sold out
            </span>
          )}
        </div>
        <div className="mt-5 flex items-start justify-between gap-4">
          <div>
            <p className="label text-stone">{product.category}</p>
            <h3 className="display mt-2 text-[22px] leading-tight text-ink transition-colors group-hover:text-brass">
              {product.name}
            </h3>
            <p className="mt-1.5 max-w-[34ch] text-sm leading-relaxed text-stone">
              {product.tagline}
            </p>
          </div>
          <div className="text-right">
            <p className="tnum display text-[22px] leading-none text-ink">{inr(product.price)}</p>
            {product.mrp > product.price && (
              <p className="tnum mt-1.5 text-sm text-stone line-through">{inr(product.mrp)}</p>
            )}
          </div>
        </div>
      </Link>
      <div className="mt-4">
        {apparel ? (
          <Link
            href={`/product/${product.slug}`}
            className="label flex w-full items-center justify-center border border-ink/25 px-7 py-4 text-ink transition-colors hover:border-brass hover:text-brass"
          >
            Choose a size
          </Link>
        ) : (
          <AddToCart product={product} full label="Add to cart" />
        )}
      </div>
    </Reveal>
  );
}

/* ---------------- UPI ticket ---------------- */

export function UpiQr({
  amount,
  note,
  size = 220,
}: {
  amount: number;
  note: string;
  size?: number;
}) {
  const [src, setSrc] = useState<string>("");
  const [copied, setCopied] = useState(false);
  const uri = upiUri(amount, note);

  useEffect(() => {
    let alive = true;
    import("qrcode").then((QR) => {
      QR.toDataURL(uri, {
        width: size * 2,
        margin: 1,
        errorCorrectionLevel: "M",
        color: { dark: "#0B1428", light: "#F5EEE3" },
      })
        .then((url) => {
          if (alive) setSrc(url);
        })
        .catch(() => {});
    });
    return () => {
      alive = false;
    };
  }, [uri, size]);

  return (
    <div className="flex flex-col items-center">
      <div
        className="stamp relative bg-paper p-3 shadow-[0_18px_50px_-24px_rgba(11,20,40,0.75)]"
        style={{ width: size + 24 }}
      >
        {src ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={src} alt={`UPI QR for ${UPI_ID}`} width={size} height={size} />
        ) : (
          <div
            className="animate-pulse bg-ink/10"
            style={{ width: size, height: size }}
            aria-hidden
          />
        )}
        <div className="mt-2.5 flex items-center justify-between">
          <span className="label text-stone">Scan with any UPI app</span>
          <a
            href={src || "#"}
            download={`upi-qr-${note}.png`}
            className="label text-brass hover:underline"
          >
            Save QR
          </a>
        </div>
      </div>
      <button
        type="button"
        onClick={() => {
          navigator.clipboard?.writeText(UPI_ID).catch(() => {});
          setCopied(true);
          window.setTimeout(() => setCopied(false), 1500);
        }}
        className="tnum label mt-4 border border-brass/50 px-4 py-2 text-brass transition-colors hover:bg-brass hover:text-ink-3"
      >
        {copied ? "UPI ID copied" : UPI_ID}
      </button>
    </div>
  );
}
