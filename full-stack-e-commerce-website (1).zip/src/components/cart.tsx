"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";

export type CartLine = {
  id: number;
  slug: string;
  name: string;
  price: number;
  mrp: number;
  image: string;
  /** Clothing size or another selected product option. */
  variant?: string;
  qty: number;
};

type CartCtx = {
  lines: CartLine[];
  add: (line: Omit<CartLine, "qty">, qty?: number) => void;
  setQty: (id: number, qty: number, variant?: string) => void;
  remove: (id: number, variant?: string) => void;
  clear: () => void;
  count: number;
  subtotal: number;
};

const Ctx = createContext<CartCtx | null>(null);
const KEY = "form_field_cart_v1";

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setLines(JSON.parse(raw));
    } catch {
      /* ignore */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    try {
      localStorage.setItem(KEY, JSON.stringify(lines));
    } catch {
      /* ignore */
    }
  }, [lines, ready]);

  const add = useCallback((line: Omit<CartLine, "qty">, qty = 1) => {
    setLines((prev) => {
      const same = (l: CartLine) =>
        l.id === line.id && (l.variant || "") === (line.variant || "");
      const found = prev.find(same);
      if (found) {
        return prev.map((l) => (same(l) ? { ...l, qty: l.qty + qty } : l));
      }
      return [...prev, { ...line, qty }];
    });
  }, []);

  const setQty = useCallback((id: number, qty: number, variant?: string) => {
    setLines((prev) =>
      qty <= 0
        ? prev.filter((l) => !(l.id === id && (l.variant || "") === (variant || "")))
        : prev.map((l) =>
            l.id === id && (l.variant || "") === (variant || "") ? { ...l, qty } : l,
          ),
    );
  }, []);

  const remove = useCallback((id: number, variant?: string) => {
    setLines((prev) =>
      prev.filter((l) => !(l.id === id && (l.variant || "") === (variant || ""))),
    );
  }, []);

  const clear = useCallback(() => setLines([]), []);

  const value = useMemo<CartCtx>(() => {
    const count = lines.reduce((s, l) => s + l.qty, 0);
    const subtotal = lines.reduce((s, l) => s + l.qty * l.price, 0);
    return { lines, add, setQty, remove, clear, count, subtotal };
  }, [lines, add, setQty, remove, clear]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useCart() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useCart must be used inside CartProvider");
  return ctx;
}

/** Logs every visitor arrival to the database. */
export function VisitTracker() {
  useEffect(() => {
    let id = "";
    try {
      id = sessionStorage.getItem("pc_sid") || "";
      if (!id) {
        id = Math.random().toString(36).slice(2) + Date.now().toString(36);
        sessionStorage.setItem("pc_sid", id);
      }
    } catch {
      /* ignore */
    }
    fetch("/api/track", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        sessionId: id,
        path: window.location.pathname,
        referrer: document.referrer || "direct",
      }),
      keepalive: true,
    }).catch(() => {});
  }, []);
  return null;
}
