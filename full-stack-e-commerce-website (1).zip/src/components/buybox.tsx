"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Minus, Plus, ShoppingBag } from "lucide-react";
import { useCart } from "@/components/cart";
import { inr } from "@/lib/format";

export type BuyProduct = {
  id: number;
  slug: string;
  name: string;
  price: number;
  mrp: number;
  image: string;
  category: string;
  stock: number;
};

const SIZES = ["XS", "S", "M", "L", "XL", "XXL"];
const field =
  "mt-2 w-full border border-ink/25 bg-paper px-4 py-3.5 text-ink focus:border-brass focus:outline-none";

export function BuyBox({ product }: { product: BuyProduct }) {
  const { add } = useCart();
  const router = useRouter();
  const apparel = product.category === "Men's Wear" || product.category === "Women's Wear";
  const [qty, setQty] = useState(1);
  const [size, setSize] = useState("");
  const [added, setAdded] = useState(false);
  const soldOut = product.stock <= 0;
  const needsSize = apparel && !size;

  function addItem(goToCheckout = false) {
    if (soldOut || needsSize) return;
    add(
      {
        id: product.id,
        slug: product.slug,
        name: product.name,
        price: product.price,
        mrp: product.mrp,
        image: product.image,
        ...(size ? { variant: `Size ${size}` } : {}),
      },
      qty,
    );
    setAdded(true);
    if (goToCheckout) router.push("/checkout");
    else window.setTimeout(() => setAdded(false), 1800);
  }

  return (
    <div>
      {apparel && (
        <div className="mb-6">
          <p className="label text-ink">Select size</p>
          <div className="mt-3 grid grid-cols-6 gap-2">
            {SIZES.map((option) => (
              <button
                key={option}
                type="button"
                onClick={() => setSize(option)}
                aria-pressed={size === option}
                className={`border px-2 py-3 text-sm transition-colors ${
                  size === option
                    ? "border-ink bg-ink text-paper"
                    : "border-ink/20 text-ink hover:border-brass hover:text-brass"
                }`}
              >
                {option}
              </button>
            ))}
          </div>
          <p className="mt-2 text-xs text-stone">Easy exchanges if the fit isn&apos;t quite right.</p>
        </div>
      )}

      <div className="flex items-center gap-5">
        <div className="flex items-center border border-ink/25">
          <button
            aria-label="Decrease quantity"
            onClick={() => setQty((q) => Math.max(1, q - 1))}
            className="px-4 py-3.5 text-ink/70 transition-colors hover:text-brass"
          >
            <Minus className="h-4 w-4" />
          </button>
          <span className="tnum w-10 text-center text-lg">{qty}</span>
          <button
            aria-label="Increase quantity"
            onClick={() => setQty((q) => Math.min(Math.max(1, product.stock), q + 1))}
            className="px-4 py-3.5 text-ink/70 transition-colors hover:text-brass"
            disabled={qty >= product.stock}
          >
            <Plus className="h-4 w-4" />
          </button>
        </div>
        <p className="tnum label text-stone">
          {soldOut ? "Out of stock" : `${product.stock} in stock`}
        </p>
      </div>

      <button
        disabled={soldOut || needsSize}
        onClick={() => addItem()}
        className="mt-6 flex w-full items-center justify-center gap-3 bg-ink px-8 py-5 text-paper transition-colors hover:bg-brass hover:text-ink-3 disabled:cursor-not-allowed disabled:bg-ink/30"
      >
        <ShoppingBag className="h-4 w-4" strokeWidth={1.6} />
        <span className="label">
          {soldOut
            ? "Sold out"
            : needsSize
              ? "Choose a size to continue"
              : added
                ? "Added to cart"
                : `Add to cart · ${inr(product.price * qty)}`}
        </span>
      </button>

      <button
        type="button"
        disabled={soldOut || needsSize}
        onClick={() => addItem(true)}
        className="mt-3 block w-full border border-ink/25 px-8 py-5 text-center transition-colors hover:border-brass hover:text-brass disabled:cursor-not-allowed disabled:opacity-40"
      >
        <span className="label">Buy now</span>
      </button>

    </div>
  );
}
