import { NextRequest, NextResponse } from "next/server";
import { isAdmin } from "@/lib/auth";
import {
  dataStore,
  listOrders,
  listProducts,
  listVisitors,
  syncLocalToSupabase,
} from "@/lib/store";

export async function GET(req: NextRequest) {
  if (!isAdmin(req))
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const [store, orders, products, visitors] = await Promise.all([
    dataStore(),
    listOrders(),
    listProducts(),
    listVisitors(),
  ]);

  return NextResponse.json({
    ...store,
    counts: {
      orders: orders.length,
      products: products.length,
      visitors: visitors.count,
      revenue: orders
        .filter((o) => ["confirmed", "shipped", "delivered"].includes(o.status))
        .reduce((s, o) => s + o.total, 0),
    },
  });
}

/** POST — copy everything collected in the local database over to Supabase. */
export async function POST(req: NextRequest) {
  if (!isAdmin(req))
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const result = await syncLocalToSupabase();
  return NextResponse.json(result, { status: result.ok ? 200 : 409 });
}
