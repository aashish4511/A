import { NextRequest, NextResponse } from "next/server";
import { ADMIN_COOKIE, ADMIN_PASS, ADMIN_USER, isAdmin, issueToken } from "@/lib/auth";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const okUser = String(body.username || "").trim().toLowerCase() === ADMIN_USER;
  const okPass = String(body.password || "").trim() === ADMIN_PASS;
  if (!okUser || !okPass) {
    return NextResponse.json(
      { error: "Wrong username or password." },
      { status: 401 },
    );
  }

  const token = issueToken();
  const res = NextResponse.json({ ok: true, user: ADMIN_USER, token });

  // SameSite=None + Secure so the session survives inside an iframe preview.
  res.cookies.set(ADMIN_COOKIE, token, {
    httpOnly: true,
    sameSite: "none",
    secure: true,
    path: "/",
    maxAge: 60 * 60 * 12,
  });
  // Non-httpOnly mirror: if the browser blocks the cookie entirely the client can
  // still authenticate with the x-admin-token header.
  res.cookies.set(`${ADMIN_COOKIE}_client`, token, {
    httpOnly: false,
    sameSite: "none",
    secure: true,
    path: "/",
    maxAge: 60 * 60 * 12,
  });
  return res;
}

export async function GET(req: NextRequest) {
  return NextResponse.json({ authed: isAdmin(req), user: ADMIN_USER });
}

export async function DELETE() {
  const res = NextResponse.json({ ok: true });
  const opts = {
    httpOnly: false,
    sameSite: "none" as const,
    secure: true,
    path: "/",
    maxAge: 0,
  };
  res.cookies.set(ADMIN_COOKIE, "", { ...opts, httpOnly: true });
  res.cookies.set(`${ADMIN_COOKIE}_client`, "", opts);
  return res;
}
