import { NextRequest, NextResponse } from "next/server";
import { isAdmin } from "@/lib/auth";
import { setOrderStatus } from "@/lib/store";

const ALLOWED = ["pending", "confirmed", "shipped", "delivered", "rejected"];

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  if (!isAdmin(req))
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await ctx.params;
  const body = await req.json();
  const status = String(body.status || "");
  if (!ALLOWED.includes(status))
    return NextResponse.json({ error: "Unknown status" }, { status: 400 });
  return NextResponse.json(await setOrderStatus(Number(id), status));
}
