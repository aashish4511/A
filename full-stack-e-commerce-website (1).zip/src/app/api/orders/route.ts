import { NextRequest, NextResponse } from "next/server";
import { isAdmin } from "@/lib/auth";
import { createOrder, listOrders } from "@/lib/store";

export async function GET(req: NextRequest) {
  if (!isAdmin(req))
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  return NextResponse.json(await listOrders());
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const items: { id: number; qty: number; variant?: string }[] = Array.isArray(body.items) ? body.items : [];
  if (items.length === 0)
    return NextResponse.json({ error: "Your cart is empty." }, { status: 400 });
  if (!body.name || !body.phone || !body.address || !body.city || !body.pincode)
    return NextResponse.json({ error: "Please fill in all delivery details." }, { status: 400 });

  const result = await createOrder({
    name: String(body.name || ""),
    phone: String(body.phone || ""),
    email: String(body.email || ""),
    address: String(body.address || ""),
    city: String(body.city || ""),
    state: String(body.state || ""),
    pincode: String(body.pincode || ""),
    paymentMethod: String(body.paymentMethod || "cod"),
    paymentRef: String(body.paymentRef || ""),
    note: String(body.note || ""),
    items,
  });

  return NextResponse.json(result, { status: 201 });
}
