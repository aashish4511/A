import { NextResponse } from "next/server";
import { dataStore } from "@/lib/store";

export async function GET() {
  const store = await dataStore();
  return NextResponse.json({
    ok: true,
    store: "Form & Field",
    database: store.backend,
    supabase: store.supabase,
    time: new Date().toISOString(),
  });
}
