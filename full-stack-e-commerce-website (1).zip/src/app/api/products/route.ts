import { NextRequest, NextResponse } from "next/server";
import { isAdmin } from "@/lib/auth";
import { listProducts, saveProduct } from "@/lib/store";

export async function GET(req: NextRequest) {
  const rows = await listProducts();
  const category = req.nextUrl.searchParams.get("category");
  return NextResponse.json(category ? rows.filter((p) => p.category === category) : rows);
}

export async function POST(req: NextRequest) {
  if (!isAdmin(req))
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = await req.json();
  const row = await saveProduct(body);
  return NextResponse.json(row, { status: 201 });
}
