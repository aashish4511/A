import { NextRequest, NextResponse } from "next/server";
import { isAdmin } from "@/lib/auth";
import { listVisitors } from "@/lib/store";

export async function GET(req: NextRequest) {
  if (!isAdmin(req))
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  return NextResponse.json(await listVisitors());
}
