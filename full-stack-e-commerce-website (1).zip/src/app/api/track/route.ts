import { NextRequest, NextResponse } from "next/server";
import { logVisit } from "@/lib/store";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  await logVisit({
    sessionId: String(body.sessionId || ""),
    path: String(body.path || "/"),
    referrer: String(body.referrer || ""),
    userAgent: req.headers.get("user-agent") || "",
  });
  return NextResponse.json({ ok: true });
}
