"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  LogOut,
  RefreshCw,
  Check,
  X,
  Truck,
  Package,
  Plus,
  Pencil,
  Trash2,
  IndianRupee,
  Users,
  ClipboardList,
  Boxes,
  Upload,
} from "lucide-react";
import { inr, dateLabel } from "@/lib/format";
import { SETUP_SQL } from "@/lib/setup-sql";
import { adminFetch, adoptUrlToken, clearToken, readToken } from "@/lib/admin-client";

type OrderItemRow = {
  id: number;
  name: string;
  image: string;
  price: number;
  qty: number;
};

type OrderRow = {
  id: number;
  code: string;
  name: string;
  phone: string;
  email: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  paymentMethod: string;
  paymentRef: string;
  note: string;
  subtotal: number;
  shipping: number;
  total: number;
  status: string;
  createdAt: string;
  items: OrderItemRow[];
};

type ProductRow = {
  id: number;
  slug: string;
  name: string;
  tagline: string;
  description: string;
  craft: string;
  care: string;
  category: string;
  image: string;
  price: number;
  mrp: number;
  stock: number;
  featured: boolean;
};

const EMPTY: ProductRow = {
  id: 0,
  slug: "",
  name: "",
  tagline: "",
  description: "",
  craft: "",
  care: "",
  category: "Watches",
  image: "https://images.pexels.com/photos/11607481/pexels-photo-11607481.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  price: 0,
  mrp: 0,
  stock: 10,
  featured: false,
};

const STATUS_STYLE: Record<string, string> = {
  pending: "bg-brass/20 text-brass border border-brass/45",
  confirmed: "bg-emerald-400/12 text-emerald-300 border border-emerald-300/35",
  shipped: "bg-sky-400/12 text-sky-300 border border-sky-300/35",
  delivered: "bg-paper/10 text-paper border border-paper/30",
  rejected: "bg-vermillion/18 text-red-300 border border-vermillion/50",
};

const input =
  "mt-2 w-full border border-paper/18 bg-ink-3/50 px-3.5 py-2.5 text-sm text-paper placeholder:text-paper/25 focus:border-brass-2 focus:outline-none";

export default function AdminPage() {
  const router = useRouter();
  const [ready, setReady] = useState(true);
  const [authed, setAuthed] = useState(false);
  const [tab, setTab] = useState<"orders" | "products" | "traffic" | "data">("orders");
  const [storeInfo, setStoreInfo] = useState<null | {
    backend: string;
    schema?: string;
    supabase: { url: string; ref: string; keyType: string; ok: boolean; message: string };
    counts: { orders: number; products: number; visitors: number; revenue: number };
  }>(null);
  const [orders, setOrders] = useState<OrderRow[]>([]);
  const [products, setProducts] = useState<ProductRow[]>([]);
  const [visitorRows, setVisitorRows] = useState<
    { id: number; path: string; referrer: string; sessionId: string; createdAt: string }[]
  >([]);
  const [visitorCount, setVisitorCount] = useState(0);
  const [form, setForm] = useState<ProductRow>(EMPTY);
  const [flash, setFlash] = useState("");
  const [filter, setFilter] = useState("all");
  const [q, setQ] = useState("");

  const load = useCallback(async () => {
    try {
      const [o, p, v] = await Promise.all([
        adminFetch("/api/orders").then((r) => (r.ok ? r.json() : null)),
        adminFetch("/api/products").then((r) => (r.ok ? r.json() : null)),
        adminFetch("/api/visitors").then((r) => (r.ok ? r.json() : null)),
      ]);
      if (Array.isArray(o)) setOrders(o);
      if (Array.isArray(p)) setProducts(p);
      if (v) {
        setVisitorRows(v.rows ?? []);
        setVisitorCount(v.count ?? 0);
      }
      const d = await adminFetch("/api/admin/data").then((r) => (r.ok ? r.json() : null));
      if (d) setStoreInfo(d);
    } catch {
      setFlash("Could not reach the database. Check the connection and refresh.");
    }
  }, []);

  // Never block the UI on this check: the panel renders immediately, data streams in,
  // and a missing session lands on the sign-in form instead of a stuck loader.
  useEffect(() => {
    let cancelled = false;
    adoptUrlToken();
    (async () => {
      try {
        const res = await adminFetch("/api/admin/login");
        const data = await res.json().catch(() => ({ authed: false }));
        if (cancelled) return;
        if (!data.authed) {
          setAuthed(false);
          setReady(true);
          setFlash("Your admin session could not be verified. Sign in again to reopen the ledger.");
          return;
        }
        setAuthed(true);
        await load();
        if (!cancelled) setReady(true);
      } catch {
        if (cancelled) return;
        setReady(true);
        setFlash("Could not verify the session. Try refreshing, or sign in again.");
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [load, router]);

  async function setStatus(id: number, status: string) {
    await adminFetch(`/api/orders/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    await load();
  }

  async function saveProduct(e: React.FormEvent) {
    e.preventDefault();
    const payload = { ...form };
    const res = await adminFetch(form.id ? `/api/products/${form.id}` : "/api/products", {
      method: form.id ? "PATCH" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (res.ok) {
      setFlash(form.id ? "Piece updated." : "Piece added to the catalogue.");
      setForm(EMPTY);
      await load();
    } else {
      setFlash("Could not save that piece.");
    }
  }

  async function removeProduct(id: number) {
    await adminFetch(`/api/products/${id}`, { method: "DELETE" });
    setFlash("Piece removed.");
    if (form.id === id) setForm(EMPTY);
    await load();
  }

  const stats = useMemo(() => {
    const revenue = orders
      .filter((o) => ["confirmed", "shipped", "delivered"].includes(o.status))
      .reduce((s, o) => s + o.total, 0);
    return {
      revenue,
      pending: orders.filter((o) => o.status === "pending").length,
      total: orders.length,
      rejected: orders.filter((o) => o.status === "rejected").length,
    };
  }, [orders]);

  const visible = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return orders
      .filter((o) => (filter === "all" ? true : o.status === filter))
      .filter((o) =>
        needle
          ? [o.code, o.name, o.phone, o.email, o.city, o.state, o.pincode, o.address]
              .join(" ")
              .toLowerCase()
              .includes(needle)
          : true,
      );
  }, [orders, filter, q]);

  if (!ready) {
    return (
      <div className="flex min-h-[70vh] flex-col items-center justify-center gap-6 bg-ink-3 px-6 text-center">
        <p className="label animate-pulse text-paper/50">Opening the ledger…</p>
        <Link href="/admin/login" className="label border border-paper/25 px-5 py-2.5 text-paper/70">
          Go to sign in
        </Link>
      </div>
    );
  }

  if (!authed) {
    return (
      <div className="flex min-h-[75vh] items-center justify-center bg-ink-3 px-6 text-paper">
        <div className="w-full max-w-[520px] border border-brass/40 bg-paper/[0.04] p-9">
          <p className="label text-brass-2">FORM &amp; FIELD · OWNER ACCESS</p>
          <h1 className="display mt-4 text-4xl">The ledger is still here.</h1>
          <p className="mt-4 text-sm leading-relaxed text-paper/60">
            Your admin session needs a fresh sign-in. Orders and products are safe; sign in again to
            continue managing the store.
          </p>
          {flash && <p className="mt-4 text-sm text-brass-2">{flash}</p>}
          <div className="mt-7 flex flex-wrap gap-3">
            <Link
              href="/admin/login"
              className="label bg-brass px-6 py-3.5 text-ink-3 hover:bg-brass-2"
            >
              Sign in again
            </Link>
            <button
              onClick={() => window.location.reload()}
              className="label border border-paper/25 px-6 py-3.5 text-paper/75 hover:border-brass-2 hover:text-brass-2"
            >
              Retry session
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-ink-3 text-paper">
      {/* header */}
      <div className="border-b border-paper/12">
        <div className="mx-auto flex max-w-[1500px] flex-wrap items-center justify-between gap-5 px-6 py-6 lg:px-10">
          <div>
                <p className="label text-brass-2">FORM &amp; FIELD · Owner</p>
            <h1 className="display mt-2 text-4xl">The Ledger</h1>
          </div>
          <div className="flex items-center gap-3">
            {authed ? (
              <span
                title="How this browser is authenticating the session"
                className="label hidden items-center gap-2 border border-emerald-300/35 px-4 py-2.5 text-emerald-300 sm:flex"
              >
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-300" />
                Signed in · {readToken() ? "token" : "cookie"}
              </span>
            ) : (
              <Link
                href="/admin/login"
                className="label border border-brass-2/60 px-4 py-2.5 text-brass-2 hover:bg-brass-2 hover:text-ink-3"
              >
                Sign in
              </Link>
            )}
            <button
              onClick={load}
              className="label flex items-center gap-2.5 border border-paper/20 px-4 py-2.5 text-paper/75 hover:border-brass-2 hover:text-brass-2"
            >
              <RefreshCw className="h-3.5 w-3.5" /> Refresh
            </button>
            <button
              onClick={async () => {
                await adminFetch("/api/admin/login", { method: "DELETE" });
                clearToken();
                router.replace("/admin/login");
              }}
              className="label flex items-center gap-2.5 bg-brass px-4 py-2.5 text-ink-3 hover:bg-brass-2"
            >
              <LogOut className="h-3.5 w-3.5" /> Sign out
            </button>
          </div>
        </div>
      </div>

      {/* stats */}
      <div className="mx-auto max-w-[1500px] px-6 lg:px-10">
        <div className="grid grid-cols-2 gap-px border border-paper/12 bg-paper/10 lg:grid-cols-4">
          {[
            { icon: IndianRupee, label: "Revenue (confirmed)", value: inr(stats.revenue) },
            { icon: ClipboardList, label: "Orders", value: `${stats.total}` },
            { icon: Package, label: "Awaiting action", value: `${stats.pending}` },
            { icon: Users, label: "Visitors logged", value: `${visitorCount}` },
          ].map((s) => (
            <div key={s.label} className="bg-ink-3 px-6 py-7">
              <s.icon className="h-4 w-4 text-brass-2" strokeWidth={1.5} />
              <p className="tnum display mt-4 text-3xl">{s.value}</p>
              <p className="label mt-2 text-paper/45">{s.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* tabs */}
      <div className="mx-auto mt-10 max-w-[1500px] px-6 lg:px-10">
        <div className="flex flex-wrap items-center gap-2.5 border-b border-paper/12 pb-4">
          {[
            { id: "orders" as const, label: "Orders" },
            { id: "products" as const, label: "Products" },
            { id: "traffic" as const, label: "Traffic" },
            { id: "data" as const, label: "Data & Supabase" },
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`label px-5 py-2.5 transition-colors ${
                tab === t.id
                  ? "bg-brass text-ink-3"
                  : "border border-paper/18 text-paper/70 hover:border-brass-2 hover:text-brass-2"
              }`}
            >
              {t.label}
            </button>
          ))}
          {flash && <p className="label ml-auto text-brass-2">{flash}</p>}
        </div>
      </div>

      <div className="mx-auto max-w-[1500px] px-6 pb-24 lg:px-10">
        {/* ---------------- ORDERS ---------------- */}
        {tab === "orders" && (
          <div>
            <div className="mt-8 flex flex-wrap items-center gap-2">
              {["all", "pending", "confirmed", "shipped", "delivered", "rejected"].map((s) => (
                <button
                  key={s}
                  onClick={() => setFilter(s)}
                  className={`label px-4 py-2 capitalize ${
                    filter === s ? "bg-paper text-ink-3" : "text-paper/55 hover:text-brass-2"
                  }`}
                >
                  {s}
                </button>
              ))}
              <div className="ml-auto flex items-center gap-4">
                <input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder="Search code, name, phone, city…"
                  className="w-full max-w-[280px] border border-paper/18 bg-ink-3/50 px-4 py-2 text-sm text-paper placeholder:text-paper/30 focus:border-brass-2 focus:outline-none"
                />
                <p className="tnum label whitespace-nowrap text-paper/40">{visible.length} shown</p>
              </div>
            </div>

            {visible.length === 0 ? (
              <div className="mt-10 border border-dashed border-paper/20 p-16 text-center">
                <p className="display text-2xl">No orders here yet.</p>
                <p className="mt-3 text-sm text-paper/50">
                  New orders land here the moment a customer checks out.
                </p>
              </div>
            ) : (
              <div className="mt-8 space-y-4">
                {visible.map((o) => (
                  <div key={o.id} className="border border-paper/12 bg-paper/[0.03]">
                    <div className="flex flex-wrap items-start justify-between gap-5 border-b border-paper/10 px-6 py-5">
                      <div>
                        <div className="flex items-center gap-3">
                          <p className="tnum display text-2xl">{o.code}</p>
                          <span className={`label px-3 py-1.5 capitalize ${STATUS_STYLE[o.status] ?? ""}`}>
                            {o.status === "pending" ? "Awaiting action" : o.status}
                          </span>
                        </div>
                        <div className="mt-4 grid gap-x-10 gap-y-3 sm:grid-cols-2 lg:grid-cols-3">
                          <div>
                            <p className="label text-paper/40">Customer</p>
                            <p className="mt-1.5 text-sm text-paper/85">{o.name}</p>
                            <a
                              href={`tel:${o.phone}`}
                              className="tnum block text-sm text-brass-2 hover:underline"
                            >
                              {o.phone}
                            </a>
                            {o.email && (
                              <a
                                href={`mailto:${o.email}`}
                                className="block truncate text-sm text-paper/60 hover:text-brass-2"
                              >
                                {o.email}
                              </a>
                            )}
                          </div>
                          <div>
                            <p className="label text-paper/40">Shipping address</p>
                            <p className="mt-1.5 max-w-[38ch] text-sm leading-relaxed text-paper/70">
                              {o.address}
                              <br />
                              {o.city}, {o.state}{" "}
                              <span className="tnum">{o.pincode}</span>
                            </p>
                          </div>
                          <div>
                            <p className="label text-paper/40">Payment &amp; note</p>
                            <p className="mt-1.5 text-sm text-paper/70">
                              {o.paymentMethod === "upi" ? "UPI transfer" : "Cash on delivery"}
                              {o.paymentRef ? ` · ref ${o.paymentRef}` : ""}
                            </p>
                            <p className="mt-1.5 max-w-[34ch] text-xs italic leading-relaxed text-paper/45">
                              {o.note ? `“${o.note}”` : "No note left by the customer."}
                            </p>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="tnum display text-2xl">{inr(o.total)}</p>
                        <p className="label mt-2 text-paper/50">
                          {o.paymentMethod === "upi" ? "UPI" : "Cash on delivery"} · {dateLabel(o.createdAt)}
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-6 px-6 py-5">
                      <div className="w-full border-y border-paper/10 bg-paper/[0.025] py-5">
                        <div className="flex flex-wrap items-center justify-between gap-3 px-1">
                          <div>
                            <p className="label text-brass-2">Products ordered</p>
                            <p className="mt-1 text-xs text-paper/45">
                              The exact items and quantities from this checkout
                            </p>
                          </div>
                          <span className="label text-paper/55">
                            {o.items.length} {o.items.length === 1 ? "line item" : "line items"}
                          </span>
                        </div>
                        {o.items.length > 0 ? (
                          <div className="mt-4 space-y-3">
                            {o.items.map((it) => (
                              <div
                                key={it.id}
                                className="flex items-center gap-4 border border-paper/10 bg-ink-3/65 p-3.5"
                              >
                                <div className="h-16 w-14 shrink-0 overflow-hidden bg-paper/10">
                                  {it.image && (
                                    // eslint-disable-next-line @next/next/no-img-element
                                    <img src={it.image} alt={it.name} className="h-full w-full object-cover" />
                                  )}
                                </div>
                                <div className="min-w-0 flex-1">
                                  <p className="text-sm font-medium text-paper">{it.name}</p>
                                  <p className="tnum mt-1 text-xs text-paper/50">
                                    Quantity {it.qty} · {inr(it.price)} each
                                  </p>
                                </div>
                                <p className="tnum display shrink-0 text-xl text-paper">
                                  {inr(it.price * it.qty)}
                                </p>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <p className="mt-4 border border-dashed border-paper/20 px-4 py-5 text-sm text-paper/55">
                            No line items were returned for this order. Refresh the ledger to reload
                            the order snapshot from Supabase.
                          </p>
                        )}
                      </div>

                      <div className="flex flex-wrap items-center gap-2.5">
                        {o.status === "pending" && (
                          <>
                            <button
                              onClick={() => setStatus(o.id, "confirmed")}
                              className="label flex items-center gap-2 bg-emerald-500/90 px-5 py-2.5 text-ink-3 hover:bg-emerald-400"
                            >
                              <Check className="h-3.5 w-3.5" /> Confirm order
                            </button>
                            <button
                              onClick={() => setStatus(o.id, "rejected")}
                              className="label flex items-center gap-2 border border-vermillion/60 px-5 py-2.5 text-red-300 hover:bg-vermillion hover:text-paper"
                            >
                              <X className="h-3.5 w-3.5" /> Reject
                            </button>
                          </>
                        )}
                        {o.status === "confirmed" && (
                          <button
                            onClick={() => setStatus(o.id, "shipped")}
                            className="label flex items-center gap-2 bg-sky-500/90 px-5 py-2.5 text-ink-3 hover:bg-sky-400"
                          >
                            <Truck className="h-3.5 w-3.5" /> Mark shipped
                          </button>
                        )}
                        {o.status === "shipped" && (
                          <button
                            onClick={() => setStatus(o.id, "delivered")}
                            className="label flex items-center gap-2 bg-paper px-5 py-2.5 text-ink-3 hover:bg-brass-2"
                          >
                            <Check className="h-3.5 w-3.5" /> Mark delivered
                          </button>
                        )}
                        {(o.status === "rejected" || o.status === "delivered") && (
                          <button
                            onClick={() => setStatus(o.id, "pending")}
                            className="label border border-paper/20 px-5 py-2.5 text-paper/60 hover:border-brass-2 hover:text-brass-2"
                          >
                            Move back to pending
                          </button>
                        )}
                        <a
                          href={`/order/${o.code}`}
                          className="label border border-paper/20 px-5 py-2.5 text-paper/60 hover:border-brass-2 hover:text-brass-2"
                        >
                          View receipt
                        </a>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ---------------- PRODUCTS ---------------- */}
        {tab === "products" && (
          <div className="mt-8 grid gap-10 lg:grid-cols-[minmax(0,1fr)_420px]">
            <div>
              <div className="overflow-x-auto border border-paper/12">
                <table className="w-full min-w-[720px] border-collapse text-left">
                  <thead>
                    <tr className="border-b border-paper/12">
                      {["Piece", "Category", "Price", "Stock", "State", ""].map((h) => (
                        <th key={h} className="label px-5 py-4 text-paper/45">
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {products.map((p) => (
                      <tr key={p.id} className="border-b border-paper/8 hover:bg-paper/[0.04]">
                        <td className="px-5 py-4">
                          <div className="flex items-center gap-3.5">
                            <div className="h-12 w-10 overflow-hidden bg-paper/10">
                              {/* eslint-disable-next-line @next/next/no-img-element */}
                              <img src={p.image} alt={p.name} className="h-full w-full object-cover" />
                            </div>
                            <div>
                              <p className="text-sm text-paper">{p.name}</p>
                              <p className="tnum text-xs text-paper/40">{p.slug}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-5 py-4 text-sm text-paper/70">{p.category}</td>
                        <td className="tnum px-5 py-4 text-sm">{inr(p.price)}</td>
                        <td className="tnum px-5 py-4 text-sm">
                          <span className={p.stock <= 5 ? "text-red-300" : "text-paper/70"}>
                            {p.stock}
                          </span>
                        </td>
                        <td className="px-5 py-4">
                          <span
                            className={`label px-3 py-1.5 ${
                              p.featured ? "bg-brass/20 text-brass-2" : "bg-paper/8 text-paper/50"
                            }`}
                          >
                            {p.featured ? "Featured" : "Catalogue"}
                          </span>
                        </td>
                        <td className="px-5 py-4">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => setForm(p)}
                              className="label flex items-center gap-1.5 border border-paper/18 px-3 py-2 text-paper/70 hover:border-brass-2 hover:text-brass-2"
                            >
                              <Pencil className="h-3 w-3" /> Edit
                            </button>
                            <button
                              onClick={() => removeProduct(p.id)}
                              className="label flex items-center gap-1.5 border border-vermillion/40 px-3 py-2 text-red-300 hover:bg-vermillion hover:text-paper"
                            >
                              <Trash2 className="h-3 w-3" /> Delete
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* form */}
            <form onSubmit={saveProduct} className="h-fit border border-brass/30 bg-paper/[0.04] p-7">
              <div className="flex items-center gap-2.5">
                <Boxes className="h-4 w-4 text-brass-2" strokeWidth={1.5} />
                <p className="label text-brass-2">{form.id ? `Edit · ${form.name}` : "Add a new piece"}</p>
              </div>

              <label className="mt-6 block">
                <span className="label text-paper/50">Name</span>
                <input className={input} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Noir Automatic Watch" required />
              </label>
              <label className="mt-4 block">
                <span className="label text-paper/50">Tagline</span>
                <input className={input} value={form.tagline} onChange={(e) => setForm({ ...form, tagline: e.target.value })} placeholder="A considered silhouette. An automatic heart." />
              </label>

              <div className="mt-4 grid grid-cols-2 gap-4">
                <label className="block">
                  <span className="label text-paper/50">Category</span>
                  <select className={input} value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                    {["Watches", "Perfumes", "Men's Wear", "Women's Wear"].map((c) => (
                      <option key={c}>{c}</option>
                    ))}
                  </select>
                </label>
                <label className="block">
                  <span className="label text-paper/50">Image path</span>
                  <input className={input} value={form.image} onChange={(e) => setForm({ ...form, image: e.target.value })} placeholder="/images/perfume.jpg or image URL" />
                </label>
                <label className="block">
                  <span className="label text-paper/50">Price (₹)</span>
                  <input type="number" min={0} className={`${input} tnum`} value={form.price} onChange={(e) => setForm({ ...form, price: Number(e.target.value) })} />
                </label>
                <label className="block">
                  <span className="label text-paper/50">MRP (₹)</span>
                  <input type="number" min={0} className={`${input} tnum`} value={form.mrp} onChange={(e) => setForm({ ...form, mrp: Number(e.target.value) })} />
                </label>
                <label className="block">
                  <span className="label text-paper/50">Stock</span>
                  <input type="number" min={0} className={`${input} tnum`} value={form.stock} onChange={(e) => setForm({ ...form, stock: Number(e.target.value) })} />
                </label>
                <label className="flex items-end gap-2.5 pb-2.5">
                  <input
                    type="checkbox"
                    checked={form.featured}
                    onChange={(e) => setForm({ ...form, featured: e.target.checked })}
                    className="h-4 w-4 accent-[#b4832e]"
                  />
                  <span className="label text-paper/60">Featured</span>
                </label>
              </div>

              <label className="mt-4 block">
                <span className="label text-paper/50">Description</span>
                <textarea rows={3} className={input} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
              </label>
              <label className="mt-4 block">
                <span className="label text-paper/50">Craft note</span>
                <textarea rows={2} className={input} value={form.craft} onChange={(e) => setForm({ ...form, craft: e.target.value })} />
              </label>
              <label className="mt-4 block">
                <span className="label text-paper/50">Care note</span>
                <textarea rows={2} className={input} value={form.care} onChange={(e) => setForm({ ...form, care: e.target.value })} />
              </label>

              <div className="mt-7 flex gap-3">
                <button type="submit" className="label flex flex-1 items-center justify-center gap-2 bg-brass px-6 py-3.5 text-ink-3 hover:bg-brass-2">
                  <Plus className="h-3.5 w-3.5" /> {form.id ? "Save changes" : "Add piece"}
                </button>
                {form.id !== 0 && (
                  <button
                    type="button"
                    onClick={() => setForm(EMPTY)}
                    className="label border border-paper/20 px-5 py-3.5 text-paper/70 hover:border-brass-2 hover:text-brass-2"
                  >
                    Cancel
                  </button>
                )}
              </div>
            </form>
          </div>
        )}

        {/* ---------------- TRAFFIC ---------------- */}
        {tab === "traffic" && (
          <div className="mt-8">
            <p className="text-sm text-paper/55">
              Every visitor who enters the shop is written to the database with the page they opened
              and where they came from. Last {visitorRows.length} of{" "}
              <span className="tnum text-brass-2">{visitorCount}</span> entries.
            </p>
            <div className="mt-6 overflow-x-auto border border-paper/12">
              <table className="w-full min-w-[640px] border-collapse text-left">
                <thead>
                  <tr className="border-b border-paper/12">
                    {["#", "Session", "Page", "Came from", "At"].map((h) => (
                      <th key={h} className="label px-5 py-4 text-paper/45">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {visitorRows.map((v) => (
                    <tr key={v.id} className="border-b border-paper/8 hover:bg-paper/[0.04]">
                      <td className="tnum px-5 py-3.5 text-sm text-paper/40">{v.id}</td>
                      <td className="tnum px-5 py-3.5 text-xs text-paper/55">{v.sessionId.slice(0, 10)}</td>
                      <td className="px-5 py-3.5 text-sm text-paper">{v.path}</td>
                      <td className="px-5 py-3.5 text-xs text-paper/55">{v.referrer}</td>
                      <td className="tnum px-5 py-3.5 text-xs text-paper/55">{dateLabel(v.createdAt)}</td>
                    </tr>
                  ))}
                  {visitorRows.length === 0 && (
                    <tr>
                      <td colSpan={5} className="px-5 py-12 text-center text-sm text-paper/45">
                        No visits recorded yet.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ---------------- DATA / SUPABASE ---------------- */}
        {tab === "data" && (
          <div className="mt-8">
            <div
              className={`border p-8 ${
                storeInfo?.supabase.ok ? "border-emerald-400/40 bg-emerald-400/8" : "border-brass/45 bg-brass/8"
              }`}
            >
              <div className="flex flex-wrap items-start justify-between gap-6">
                <div>
                  <p className="label text-paper/50">Active database</p>
                  <p className="display mt-3 text-4xl">
                    {storeInfo?.supabase.ok ? "Supabase Postgres" : "Local PostgreSQL"}
                  </p>
                  <p className="mt-3 max-w-[62ch] text-sm leading-relaxed text-paper/60">
                    {storeInfo?.supabase.ok
                      ? "Orders, products and every visitor entry are written to your Supabase project from here on."
                      : "Supabase is configured but not answering yet, so the shop is writing to the bundled PostgreSQL database. Nothing is lost — once Supabase is live the same code starts writing there instead."}
                  </p>
                </div>
                <div className="flex flex-wrap gap-3">
                  <button
                    onClick={load}
                    className="label flex items-center gap-2.5 border border-paper/25 px-5 py-3 text-paper/80 hover:border-brass-2 hover:text-brass-2"
                  >
                    <RefreshCw className="h-3.5 w-3.5" /> Check connection
                  </button>
                  <button
                    onClick={async () => {
                      setFlash("Copying local data to Supabase…");
                      const res = await adminFetch("/api/admin/data", { method: "POST" });
                      const d = await res.json();
                      if (d.ok && d.copied) {
                        setFlash(
                          `Copied to Supabase — orders ${d.copied.orders}, items ${d.copied.items}, products ${d.copied.products}, visitors ${d.copied.visitors}.`,
                        );
                      } else {
                        setFlash(d.message || "Could not copy data.");
                      }
                      await load();
                    }}
                    className="label flex items-center gap-2.5 bg-brass px-5 py-3 text-ink-3 hover:bg-brass-2"
                  >
                    <Upload className="h-3.5 w-3.5" /> Copy local data to Supabase
                  </button>
                </div>
              </div>

              <div className="mt-8 grid gap-px border border-paper/12 bg-paper/10 sm:grid-cols-2 lg:grid-cols-4">
                {[
                  ["Project ref", storeInfo?.supabase.ref ?? "—"],
                  [
                    "Tables in use",
                    storeInfo?.schema === "shop"
                      ? "orders · order_items · products"
                      : storeInfo?.schema === "pc"
                        ? "Form & Field schema"
                        : "not detected yet",
                  ],
                  ["API key type", storeInfo?.supabase.keyType ?? "—"],
                  ["Status", storeInfo?.supabase.message ?? "—"],
                ].map(([k, v]) => (
                  <div key={k} className="bg-ink-3 px-5 py-5">
                    <p className="label text-paper/45">{k}</p>
                    <p className="tnum mt-2.5 break-words text-sm text-paper/85">{v}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-8 grid gap-8 lg:grid-cols-[minmax(0,1fr)_360px]">
              <div className="border border-paper/12 p-7">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <p className="label text-brass-2">One-time setup · run this SQL once</p>
                  <button
                    onClick={() => {
                      navigator.clipboard?.writeText(SETUP_SQL).catch(() => {});
                      setFlash("SQL copied — paste it into the Supabase SQL editor.");
                    }}
                    className="label border border-paper/20 px-4 py-2.5 text-paper/75 hover:border-brass-2 hover:text-brass-2"
                  >
                    Copy SQL
                  </button>
                </div>
                <p className="mt-4 max-w-[70ch] text-sm leading-relaxed text-paper/55">
                  Your project already holds <span className="text-paper/80">products</span>,{" "}
                  <span className="text-paper/80">orders</span> and{" "}
                  <span className="text-paper/80">order_items</span>, and the shop reads and writes
                  them directly — so orders show up here the moment they are placed. This small
                  script only adds the visitor log. Supabase →{" "}
                  <span className="text-paper/80">SQL Editor</span> → paste →{" "}
                  <span className="text-paper/80">Run</span>. (The full DDL for a blank project is at{" "}
                  <span className="tnum text-brass-2">supabase/schema.sql</span>.)
                </p>
                <pre className="mt-6 max-h-[420px] overflow-auto border border-paper/12 bg-ink-3/60 p-5 text-[11.5px] leading-[1.75] text-paper/70">
                  <code>{SETUP_SQL}</code>
                </pre>
              </div>

              <div>
                <div className="border border-paper/12 p-7">
                  <p className="label text-brass-2">Currently stored</p>
                  <div className="mt-6 space-y-4">
                    {[
                      ["Orders", storeInfo?.counts.orders ?? 0],
                      ["Products", storeInfo?.counts.products ?? 0],
                      ["Visitor entries", storeInfo?.counts.visitors ?? 0],
                      ["Confirmed revenue", inr(storeInfo?.counts.revenue ?? 0)],
                    ].map(([k, v]) => (
                      <div key={String(k)} className="flex items-baseline justify-between border-b border-paper/10 pb-3">
                        <span className="label text-paper/50">{k}</span>
                        <span className="tnum display text-xl">{v}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-6 border border-paper/12 p-7">
                  <p className="label text-brass-2">Wiring</p>
                  <ul className="mt-5 space-y-3 text-xs leading-[1.9] text-paper/55">
                    <li>
                      <span className="text-paper/80">SUPABASE_URL</span> — project endpoint
                    </li>
                    <li>
                      <span className="text-paper/80">SUPABASE_PUBLISHABLE_KEY</span> — the key you
                      shared, kept server-side
                    </li>
                    <li>
                      <span className="text-paper/80">SUPABASE_SECRET_KEY</span> — optional, bypasses
                      Row Level Security
                    </li>
                    <li>
                      <span className="text-paper/80">DATABASE_URL</span> — local PostgreSQL fallback
                    </li>
                  </ul>
                  <p className="mt-6 text-xs leading-relaxed text-paper/45">
                    Every read and write goes through one store layer, so a Supabase outage can never
                    take the checkout down — orders fall back to PostgreSQL and the receipt is still
                    issued.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
