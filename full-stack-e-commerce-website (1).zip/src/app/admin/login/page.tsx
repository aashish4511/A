"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Lock, Loader2, AlertCircle, KeyRound } from "lucide-react";
import { clearToken, saveToken } from "@/lib/admin-client";

export default function AdminLoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    clearToken();
  }, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Login failed.");
      if (data.token) saveToken(data.token);
      // Hand the token over in the URL too, so even a browser that blocks both
      // cookies and storage can open the panel (the page strips it immediately).
      const next = data.token
        ? `/admin?t=${encodeURIComponent(data.token)}`
        : "/admin";
      // Small delay so the Set-Cookie header is committed before navigating.
      window.setTimeout(() => router.replace(next), 60);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Login failed.");
      setBusy(false);
    }
  }

  return (
    <div className="relative min-h-[calc(100vh-120px)] overflow-hidden bg-ink-3">
      <img
        src="images/hero.jpg"
        alt=""
        aria-hidden
        className="absolute inset-0 h-full w-full object-cover opacity-25"
      />
      <div className="absolute inset-0 bg-gradient-to-br from-ink-3 via-ink-3/92 to-ink-3/70" />

      <div className="relative mx-auto flex max-w-[1400px] flex-col items-start px-6 py-20 lg:px-12">
        <p className="label text-brass-2">FORM &amp; FIELD · Owner access</p>
        <h1 className="display mt-5 max-w-[16ch] text-[clamp(2.4rem,6vw,4.6rem)] leading-[1.02] text-paper">
          The workshop
          <span className="font-light italic text-brass-2"> ledger.</span>
        </h1>

        <form
          onSubmit={submit}
          className="mt-12 w-full max-w-[440px] border border-brass/35 bg-paper/[0.06] p-8 backdrop-blur-sm"
        >
          <div className="flex items-center gap-3">
            <Lock className="h-4 w-4 text-brass-2" strokeWidth={1.5} />
            <p className="label text-paper/80">Admin sign in</p>
          </div>

          <label className="mt-8 block">
            <span className="label text-paper/55">Username</span>
            <input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              autoComplete="username"
              autoFocus
              className="mt-2 w-full border border-paper/20 bg-ink-3/60 px-4 py-3.5 text-paper placeholder:text-paper/30 focus:border-brass-2 focus:outline-none"
              placeholder="admin"
            />
          </label>

          <label className="mt-5 block">
            <span className="label text-paper/55">Password</span>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
              className="mt-2 w-full border border-paper/20 bg-ink-3/60 px-4 py-3.5 text-paper placeholder:text-paper/30 focus:border-brass-2 focus:outline-none"
              placeholder="•••••"
            />
          </label>

          {error && (
            <p className="mt-5 flex items-center gap-2.5 border border-vermillion/50 bg-vermillion/15 px-4 py-3 text-sm text-paper">
              <AlertCircle className="h-4 w-4 text-vermillion" />
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={busy}
            className="mt-8 flex w-full items-center justify-center gap-3 bg-brass px-8 py-4 text-ink-3 transition-colors hover:bg-brass-2 disabled:opacity-60"
          >
            {busy && <Loader2 className="h-4 w-4 animate-spin" />}
            <span className="label">Enter the ledger</span>
          </button>

          <p className="mt-6 flex items-start gap-2.5 text-xs leading-relaxed text-paper/45">
            <KeyRound className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            Restricted to the shop owner. The session token is signed, expires after 12 hours, and
            is kept in an HttpOnly cookie — with a header fallback for browsers that block cookies
            in embedded previews.
          </p>
        </form>

        <Link href="/" className="label mt-10 text-paper/55 hover:text-brass-2">
          ← Back to the shop
        </Link>
      </div>
    </div>
  );
}
