"use client";

import Link from "next/link";
import { useEffect } from "react";

/** Route-level safety net: the panel never dies blank. */
export default function AdminError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("[admin]", error);
  }, [error]);

  return (
    <div className="flex min-h-[70vh] items-center justify-center bg-ink-3 px-6">
      <div className="w-full max-w-[520px] border border-vermillion/45 bg-paper/[0.05] p-8 text-paper">
        <p className="label text-brass-2">FORM &amp; FIELD · Owner</p>
        <h1 className="display mt-4 text-3xl">The ledger did not open.</h1>
        <p className="mt-4 text-sm leading-relaxed text-paper/60">
          Something in the admin panel failed to render. Your orders and products are safe in the
          database — reload the panel or sign in again.
        </p>
        <p className="tnum mt-4 break-words border border-paper/12 bg-ink-3/60 px-4 py-3 text-xs text-paper/45">
          {error.message || "Unknown error"}
        </p>
        <div className="mt-7 flex flex-wrap gap-3">
          <button
            onClick={reset}
            className="label bg-brass px-6 py-3.5 text-ink-3 hover:bg-brass-2"
          >
            Try again
          </button>
          <Link
            href="/admin/login"
            className="label border border-paper/25 px-6 py-3.5 text-paper/80 hover:border-brass-2 hover:text-brass-2"
          >
            Sign in
          </Link>
          <Link
            href="/"
            className="label border border-paper/25 px-6 py-3.5 text-paper/80 hover:border-brass-2 hover:text-brass-2"
          >
            Back to shop
          </Link>
        </div>
      </div>
    </div>
  );
}
