"use client";

import Link from "next/link";
import { Minus, Plus, Trash2, ArrowRight, ShoppingBag } from "lucide-react";
import { useCart } from "@/components/cart";
import { inr } from "@/lib/format";

export default function CartPage() {
  const { lines, setQty, remove, subtotal, clear, count } = useCart();
  const shipping = subtotal >= 2500 ? 0 : lines.length ? 149 : 0;
  const total = subtotal + shipping;

  return (
    <div className="mx-auto max-w-[1400px] px-6 pb-24 pt-14 lg:px-12 lg:pt-20">
      <div className="flex flex-wrap items-end justify-between gap-6">
        <div>
          <p className="label text-brass">Your order</p>
          <h1 className="display mt-4 text-[clamp(2.4rem,6vw,4.4rem)] text-ink">The cart</h1>
        </div>
        {lines.length > 0 && (
          <button onClick={clear} className="label border-b border-ink/25 pb-1 text-stone hover:border-vermillion hover:text-vermillion">
            Empty the cart
          </button>
        )}
      </div>

      <div className="mt-10 h-px w-full bg-ink/15" />

      {lines.length === 0 ? (
        <div className="mt-16 border border-dashed border-ink/25 px-8 py-20 text-center">
          <ShoppingBag className="mx-auto h-8 w-8 text-brass" strokeWidth={1.2} />
          <p className="display mt-6 text-3xl text-ink">Nothing packed yet.</p>
          <p className="mx-auto mt-4 max-w-[42ch] text-stone">
            Six pieces are waiting in the catalogue — brass, terracotta, kansa and copper, all made
            by hand and shipped in reed straw.
          </p>
          <Link
            href="/shop"
            className="label mt-8 inline-flex items-center gap-3 bg-ink px-8 py-4 text-paper hover:bg-brass hover:text-ink-3"
          >
            Browse the catalogue <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      ) : (
        <div className="mt-12 grid gap-14 lg:grid-cols-[minmax(0,1.45fr)_minmax(0,1fr)]">
          <div>
            {lines.map((l) => (
              <div
                key={`${l.id}-${l.variant || "default"}`}
                className="grid grid-cols-[96px_minmax(0,1fr)] gap-6 border-b border-ink/12 py-7 sm:grid-cols-[120px_minmax(0,1fr)]"
              >
                <Link href={`/product/${l.slug}`} className="block">
                  <div className="sweep aspect-[4/5] overflow-hidden bg-ink/10">
                    <img src={l.image} alt={l.name} className="h-full w-full object-cover" />
                  </div>
                </Link>
                <div>
                  <div className="flex flex-wrap items-start justify-between gap-4">
                    <div>
                      <Link href={`/product/${l.slug}`}>
                        <h3 className="display text-2xl text-ink hover:text-brass">{l.name}</h3>
                      </Link>
                      <p className="tnum mt-1.5 text-sm text-stone">
                        {inr(l.price)} each · inclusive of taxes{l.variant ? ` · ${l.variant}` : ""}
                      </p>
                    </div>
                    <p className="tnum display text-2xl text-ink">{inr(l.price * l.qty)}</p>
                  </div>
                  <div className="mt-5 flex items-center gap-5">
                    <div className="flex items-center border border-ink/20">
                      <button
                        aria-label="Decrease"
                        onClick={() => setQty(l.id, l.qty - 1, l.variant)}
                        className="px-3.5 py-2.5 text-ink/70 hover:text-brass"
                      >
                        <Minus className="h-3.5 w-3.5" />
                      </button>
                      <span className="tnum w-8 text-center">{l.qty}</span>
                      <button
                        aria-label="Increase"
                        onClick={() => setQty(l.id, l.qty + 1, l.variant)}
                        className="px-3.5 py-2.5 text-ink/70 hover:text-brass"
                      >
                        <Plus className="h-3.5 w-3.5" />
                      </button>
                    </div>
                    <button
                      onClick={() => remove(l.id, l.variant)}
                      className="label flex items-center gap-2 text-stone hover:text-vermillion"
                    >
                      <Trash2 className="h-3.5 w-3.5" /> Remove
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <aside>
            <div className="sticky top-32 border border-ink/15 bg-paper-2/50 p-8">
              <p className="label text-brass">Summary</p>
              <div className="mt-6 space-y-3.5">
                <div className="flex justify-between text-stone">
                  <span>Subtotal ({count} items)</span>
                  <span className="tnum text-ink">{inr(subtotal)}</span>
                </div>
                <div className="flex justify-between text-stone">
                  <span>Shipping</span>
                  <span className="tnum text-ink">{shipping === 0 ? "Free" : inr(shipping)}</span>
                </div>
                {shipping > 0 && (
                  <p className="tnum text-xs leading-relaxed text-brass">
                    Add {inr(2500 - subtotal)} more for free shipping.
                  </p>
                )}
                <div className="h-px bg-ink/15" />
                <div className="flex items-baseline justify-between">
                  <span className="label text-ink">Total</span>
                  <span className="tnum display text-3xl text-ink">{inr(total)}</span>
                </div>
              </div>
              <Link
                href="/checkout"
                className="label mt-8 flex w-full items-center justify-center gap-3 bg-ink px-8 py-5 text-paper transition-colors hover:bg-brass hover:text-ink-3"
              >
                Proceed to checkout <ArrowRight className="h-4 w-4" />
              </Link>
              <p className="mt-5 text-xs leading-relaxed text-stone">
                Cash on Delivery and UPI both accepted. UPI orders get a QR for the exact total at
                checkout.
              </p>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
}
