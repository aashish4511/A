import Link from "next/link";
import { listProducts } from "@/lib/store";
import { ProductCard, Reveal } from "@/components/ui";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Shop watches, perfumes & clothing — Form & Field",
};

const FILTERS = ["All", "Watches", "Perfumes", "Men's Wear", "Women's Wear"];
const categoryHref = (category: string) => `/shop?category=${encodeURIComponent(category)}`;

export default async function ShopPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string }>;
}) {
  const { category } = await searchParams;
  const active = category && FILTERS.includes(category) ? category : "All";
  const all = await listProducts();
  const rows = active === "All" ? all : all.filter((p) => p.category === active);

  return (
    <div className="mx-auto max-w-[1400px] px-6 pb-24 pt-14 lg:px-12 lg:pt-20">
      <Reveal>
        <p className="label text-brass">FORM &amp; FIELD · THE COLLECTION</p>
        <h1 className="display mt-5 text-[clamp(2.6rem,7vw,5.2rem)] text-ink">
          The everyday edit,
          <span className="font-light italic text-stone"> all in one place.</span>
        </h1>
      </Reveal>

      <Reveal delay={110}>
        <div className="mt-10 flex flex-wrap items-center gap-2.5 border-y border-ink/12 py-5">
          {FILTERS.map((f) => {
            const isActive = f === active;
            return (
              <Link
                key={f}
                href={f === "All" ? "/shop" : categoryHref(f)}
                className={`label px-5 py-2.5 transition-colors ${
                  isActive
                    ? "bg-ink text-paper"
                    : "border border-ink/20 text-ink/70 hover:border-brass hover:text-brass"
                }`}
              >
                {f}
              </Link>
            );
          })}
          <p className="tnum label ml-auto text-stone">
            {rows.length} {rows.length === 1 ? "find" : "finds"}
          </p>
        </div>
      </Reveal>

      {rows.length === 0 ? (
        <div className="mt-20 border border-dashed border-ink/25 p-16 text-center">
          <p className="display text-2xl text-ink">Nothing in this collection just yet.</p>
          <p className="mt-3 text-stone">Check back soon — or browse the full edit.</p>
        </div>
      ) : (
        <div className="mt-14 grid gap-x-8 gap-y-16 sm:grid-cols-2 lg:grid-cols-3">
          {rows.map((p, i) => (
            <ProductCard key={p.id} index={i} product={p} />
          ))}
        </div>
      )}
    </div>
  );
}
