import Link from "next/link";
import { notFound } from "next/navigation";
import { getOrderByCode } from "@/lib/store";
import { UpiQr } from "@/components/ui";
import { inr, dateLabel, UPI_ID } from "@/lib/format";
import { Check, X, Truck, Package, MapPin, Banknote, QrCode } from "lucide-react";

export const dynamic = "force-dynamic";

const STEPS = [
  { key: "placed", label: "Order placed", icon: Package },
  { key: "confirmed", label: "Confirmed by workshop", icon: Check },
  { key: "shipped", label: "Handed to courier", icon: Truck },
  { key: "delivered", label: "Delivered", icon: MapPin },
];

const ORDER = ["pending", "confirmed", "shipped", "delivered"];

export default async function OrderPage({ params }: { params: Promise<{ code: string }> }) {
  const { code } = await params;
  const order = await getOrderByCode(code);
  if (!order) notFound();
  const items = order.items;

  const rejected = order.status === "rejected";
  const stepIndex = ORDER.indexOf(order.status);

  return (
    <div className="mx-auto max-w-[1180px] px-6 pb-24 pt-12 lg:px-12 lg:pt-16">
      <div className="flex flex-wrap items-end justify-between gap-6">
        <div>
          <p className="label text-brass">FORM &amp; FIELD · ORDER RECEIPT</p>
          <h1 className="display mt-4 text-[clamp(2.3rem,6vw,4.4rem)] text-ink">
            {rejected ? "This order was cancelled." : "Thank you. It is with us."}
          </h1>
          <p className="tnum label mt-4 text-stone">
            Order {order.code} · placed {dateLabel(order.createdAt)}
          </p>
        </div>
        <div
          className={`label px-5 py-2.5 ${
            rejected
              ? "bg-vermillion text-paper"
              : order.status === "pending"
                ? "bg-brass text-ink-3"
                : "bg-ink text-paper"
          }`}
        >
          {order.status === "pending"
            ? "Awaiting confirmation"
            : order.status === "confirmed"
              ? "Confirmed"
              : order.status === "shipped"
                ? "Shipped"
                : order.status === "delivered"
                  ? "Delivered"
                  : "Rejected"}
        </div>
      </div>

      {rejected ? (
        <div className="mt-10 border border-vermillion/40 bg-vermillion/8 p-8">
          <p className="flex items-center gap-3 text-vermillion">
            <X className="h-5 w-5" />
            <span className="label">Order rejected by the workshop</span>
          </p>
          <p className="mt-4 max-w-[62ch] text-[15px] leading-[1.8] text-stone">
            We could not confirm this order — usually because the piece went out of stock or the
            address could not be verified. Nothing has been charged. If you paid by UPI, write to
            us with order code <span className="tnum text-ink">{order.code}</span> and we will
            refund within 3 working days.
          </p>
          <Link href="/shop" className="label mt-6 inline-block border border-ink/25 px-6 py-3 text-ink hover:border-brass hover:text-brass">
            Back to the catalogue
          </Link>
        </div>
      ) : (
        <div className="mt-10 grid gap-4 sm:grid-cols-4">
          {STEPS.map((s, i) => {
            const done = i <= stepIndex;
            return (
              <div
                key={s.key}
                className={`border p-5 ${done ? "border-brass bg-brass/10" : "border-ink/15"}`}
              >
                <s.icon className={`h-5 w-5 ${done ? "text-brass" : "text-stone/50"}`} strokeWidth={1.5} />
                <p className={`label mt-4 ${done ? "text-ink" : "text-stone/60"}`}>{s.label}</p>
                <p className="tnum mt-1.5 text-xs text-stone">{i === 0 ? dateLabel(order.createdAt) : done ? "Done" : "Pending"}</p>
              </div>
            );
          })}
        </div>
      )}

      <div className="mt-14 grid gap-12 lg:grid-cols-[minmax(0,1.25fr)_minmax(0,1fr)]">
        <div>
          <h2 className="label text-ink">What you ordered</h2>
          <div className="mt-6">
            {items.map((it) => (
              <div key={it.id} className="flex items-center gap-5 border-b border-ink/12 py-5">
                <div className="h-20 w-16 shrink-0 overflow-hidden bg-ink/10">
                  <img src={it.image} alt={it.name} className="h-full w-full object-cover" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="display text-xl text-ink">{it.name}</p>
                  <p className="tnum mt-1 text-sm text-stone">
                    {inr(it.price)} × {it.qty}
                  </p>
                </div>
                <p className="tnum display text-xl text-ink">{inr(it.price * it.qty)}</p>
              </div>
            ))}
            <div className="mt-6 space-y-3">
              <div className="flex justify-between text-stone">
                <span>Subtotal</span>
                <span className="tnum text-ink">{inr(order.subtotal)}</span>
              </div>
              <div className="flex justify-between text-stone">
                <span>Shipping</span>
                <span className="tnum text-ink">{order.shipping === 0 ? "Free" : inr(order.shipping)}</span>
              </div>
              <div className="flex items-baseline justify-between border-t border-ink/15 pt-4">
                <span className="label text-ink">Total</span>
                <span className="tnum display text-3xl text-ink">{inr(order.total)}</span>
              </div>
            </div>
          </div>

          <div className="mt-10 border border-ink/15 p-7">
            <p className="label text-brass">Delivering to</p>
            <p className="mt-4 text-[15px] leading-[1.9] text-ink">
              {order.name}
              <br />
              {order.address}
              <br />
              {order.city}, {order.state} <span className="tnum">{order.pincode}</span>
              <br />
              <span className="tnum text-stone">+91 {order.phone}</span>
            </p>
            <p className="mt-5 flex items-center gap-2.5 text-stone">
              {order.paymentMethod === "upi" ? (
                <>
                  <QrCode className="h-4 w-4 text-brass" />
                  <span className="label">Paid by UPI · {UPI_ID}</span>
                </>
              ) : (
                <>
                  <Banknote className="h-4 w-4 text-brass" />
                  <span className="label">Cash on Delivery · pay the courier</span>
                </>
              )}
            </p>
            {order.note && <p className="mt-4 text-sm italic text-stone">&ldquo;{order.note}&rdquo;</p>}
          </div>
        </div>

        <aside>
          {order.paymentMethod === "upi" && !rejected ? (
            <div className="border border-brass/45 bg-ink-3 p-8 text-center">
              <p className="label text-brass-2">
                {order.status === "pending" ? "Complete your payment" : "Payment received"}
              </p>
              <p className="tnum display mt-4 text-5xl text-paper">{inr(order.total)}</p>
              <p className="label mt-3 text-paper/55">UPI · {order.code}</p>
              <div className="mt-7 flex justify-center">
                <UpiQr amount={order.total} note={`Order ${order.code}`} size={200} />
              </div>
              <p className="mt-6 text-xs leading-relaxed text-paper/60">
                Scan and pay <span className="tnum">{inr(order.total)}</span> to{" "}
                <span className="tnum">{UPI_ID}</span>, then keep the UPI reference. We match it to
                order {order.code} and confirm within a few hours.
              </p>
            </div>
          ) : (
            <div className="border border-ink/15 bg-paper-2/50 p-8">
              <p className="label text-brass">Cash on Delivery</p>
              <p className="tnum display mt-4 text-5xl text-ink">{inr(order.total)}</p>
              <p className="mt-5 text-sm leading-relaxed text-stone">
                Keep <span className="tnum text-ink">{inr(order.total)}</span> ready for the courier.
                Our executive will call you on <span className="tnum text-ink">{order.phone}</span>{" "}
                before delivery.
              </p>
              <div className="mt-7 border-t border-ink/15 pt-6">
                <p className="label text-stone">Changed your mind?</p>
                <p className="mt-2 text-sm leading-relaxed text-stone">
                  Reply to the WhatsApp confirmation and we will cancel it before it ships.
                </p>
              </div>
            </div>
          )}

          <Link
            href="/shop"
            className="label mt-8 block border border-ink/25 px-8 py-4 text-center text-ink hover:border-brass hover:text-brass"
          >
            Continue shopping
          </Link>
        </aside>
      </div>
    </div>
  );
}
