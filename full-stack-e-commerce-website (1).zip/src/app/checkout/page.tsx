"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCart } from "@/components/cart";
import { UpiQr } from "@/components/ui";
import { inr, UPI_ID } from "@/lib/format";
import { Banknote, QrCode, Loader2, AlertCircle } from "lucide-react";

const STATES = [
  "Andhra Pradesh", "Assam", "Bihar", "Chhattisgarh", "Delhi NCT", "Goa", "Gujarat",
  "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh",
  "Maharashtra", "Odisha", "Punjab", "Rajasthan", "Tamil Nadu", "Telangana", "Uttar Pradesh",
  "Uttarakhand", "West Bengal",
];

const field =
  "mt-2 w-full border border-ink/22 bg-paper px-4 py-3.5 text-ink placeholder:text-stone/55 focus:border-brass focus:outline-none";

export default function CheckoutPage() {
  const { lines, subtotal, clear, count } = useCart();
  const router = useRouter();
  const [method, setMethod] = useState<"cod" | "upi">("upi");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({
    name: "",
    phone: "",
    email: "",
    address: "",
    city: "",
    state: "Uttar Pradesh",
    pincode: "",
    note: "",
  });

  const shipping = subtotal >= 2500 ? 0 : lines.length ? 149 : 0;
  const total = subtotal + shipping;
  const note = useMemo(
    () => (lines.length ? `Order ${lines[0].name} +${Math.max(0, count - 1)} more` : "Form and Field"),
    [lines, count],
  );

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  async function placeOrder() {
    setError("");
    if (lines.length === 0) {
      setError("Your cart is empty.");
      return;
    }
    if (!form.name || !form.phone || !form.address || !form.city || !form.pincode) {
      setError("Please complete name, phone, address, city and pincode.");
      return;
    }
    if (!/^[0-9]{10}$/.test(form.phone.replace(/\s/g, ""))) {
      setError("Please enter a 10-digit mobile number.");
      return;
    }
    if (!/^[0-9]{6}$/.test(form.pincode)) {
      setError("Please enter a valid 6-digit pincode.");
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          paymentMethod: method,
          items: lines.map((l) => ({ id: l.id, qty: l.qty, variant: l.variant || "" })), 
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Something went wrong.");
      clear();
      router.push(`/order/${data.code}`);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong.");
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-[1400px] px-6 pb-24 pt-12 lg:px-12 lg:pt-16">
      <p className="label text-brass">Step 02 · Delivery &amp; payment</p>
      <h1 className="display mt-4 text-[clamp(2.3rem,5.6vw,4.2rem)] text-ink">
        Where should we
        <span className="font-light italic text-stone"> send it?</span>
      </h1>

      <div className="mt-12 grid gap-14 lg:grid-cols-[minmax(0,1.25fr)_minmax(0,1fr)]">
        {/* ---- form ---- */}
        <div>
          <section>
            <div className="flex items-baseline justify-between">
              <h2 className="label text-ink">Contact details</h2>
              <Link href="/cart" className="label text-stone hover:text-brass">
                Edit cart
              </Link>
            </div>
            <div className="mt-6 grid gap-5 sm:grid-cols-2">
              <label className="block">
                <span className="label text-stone">Full name</span>
                <input className={field} value={form.name} onChange={set("name")} placeholder="Ananya Rao" />
              </label>
              <label className="block">
                <span className="label text-stone">Mobile number</span>
                <input className={`${field} tnum`} value={form.phone} onChange={set("phone")} placeholder="98765 43210" inputMode="numeric" />
              </label>
              <label className="block sm:col-span-2">
                <span className="label text-stone">Email (for the receipt)</span>
                <input className={field} value={form.email} onChange={set("email")} placeholder="you@example.com" type="email" />
              </label>
            </div>
          </section>

          <section className="mt-12">
            <h2 className="label text-ink">Delivery address</h2>
            <div className="mt-6 grid gap-5 sm:grid-cols-2">
              <label className="block sm:col-span-2">
                <span className="label text-stone">Flat, house, street</span>
                <textarea className={field} rows={3} value={form.address} onChange={set("address")} placeholder="14, Sarai Kazi, near the old clock tower" />
              </label>
              <label className="block">
                <span className="label text-stone">City / town</span>
                <input className={field} value={form.city} onChange={set("city")} placeholder="Your city" />
              </label>
              <label className="block">
                <span className="label text-stone">State</span>
                <select className={field} value={form.state} onChange={set("state")}>
                  {STATES.map((s) => (
                    <option key={s}>{s}</option>
                  ))}
                </select>
              </label>
              <label className="block">
                <span className="label text-stone">Pincode</span>
                <input className={`${field} tnum`} value={form.pincode} onChange={set("pincode")} placeholder="244001" inputMode="numeric" />
              </label>
              <label className="block">
                <span className="label text-stone">Note for the courier (optional)</span>
                <input className={field} value={form.note} onChange={set("note")} placeholder="Leave with the neighbour at 14B" />
              </label>
            </div>
          </section>

          <section className="mt-12">
            <h2 className="label text-ink">Payment method</h2>
            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              {[
                { id: "upi" as const, icon: QrCode, title: "UPI · Scan & pay", body: `A QR for ${inr(total)} is generated for ${UPI_ID}` },
                { id: "cod" as const, icon: Banknote, title: "Cash on Delivery", body: "Pay the courier in cash when the box arrives" },
              ].map((m) => (
                <button
                  key={m.id}
                  onClick={() => setMethod(m.id)}
                  className={`flex items-start gap-4 border p-6 text-left transition-colors ${
                    method === m.id
                      ? "border-brass bg-brass/10"
                      : "border-ink/20 hover:border-ink/45"
                  }`}
                >
                  <m.icon className={`mt-1 h-5 w-5 ${method === m.id ? "text-brass" : "text-stone"}`} strokeWidth={1.5} />
                  <div>
                    <p className="label text-ink">{m.title}</p>
                    <p className="mt-2 text-sm leading-relaxed text-stone">{m.body}</p>
                  </div>
                </button>
              ))}
            </div>
          </section>

          {error && (
            <div className="mt-8 flex items-start gap-3 border border-vermillion/40 bg-vermillion/8 px-5 py-4">
              <AlertCircle className="mt-0.5 h-4 w-4 text-vermillion" />
              <p className="text-sm text-vermillion">{error}</p>
            </div>
          )}

          <button
            onClick={placeOrder}
            disabled={busy || lines.length === 0}
            className="mt-8 flex w-full items-center justify-center gap-3 bg-ink px-8 py-5 text-paper transition-colors hover:bg-brass hover:text-ink-3 disabled:cursor-not-allowed disabled:bg-ink/35"
          >
            {busy && <Loader2 className="h-4 w-4 animate-spin" />}
            <span className="label">
              {busy ? "Placing order…" : method === "upi" ? "Place order & show UPI QR" : "Place order · Cash on Delivery"}
            </span>
          </button>
          <p className="mt-4 text-xs leading-relaxed text-stone">
            By placing this order you agree to our replacement policy. Your details are stored only
            to deliver the order.
          </p>
        </div>

        {/* ---- summary + UPI ticket ---- */}
        <aside>
          <div className="sticky top-32">
            <div className="border border-ink/15 bg-paper-2/50 p-8">
              <p className="label text-brass">Order summary</p>
              <div className="mt-6 space-y-4">
                {lines.map((l) => (
                  <div key={`${l.id}-${l.variant || "default"}`} className="flex items-center gap-4">
                    <div className="h-14 w-12 shrink-0 overflow-hidden bg-ink/10">
                      <img src={l.image} alt={l.name} className="h-full w-full object-cover" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm text-ink">{l.name}</p>
                      <p className="tnum text-xs text-stone">
                        Qty {l.qty}{l.variant ? ` · ${l.variant}` : ""}
                      </p>
                    </div>
                    <p className="tnum text-sm text-ink">{inr(l.price * l.qty)}</p>
                  </div>
                ))}
                {lines.length === 0 && (
                  <p className="text-sm text-stone">Your cart is empty.</p>
                )}
              </div>
              <div className="mt-7 space-y-3 border-t border-ink/15 pt-5">
                <div className="flex justify-between text-sm text-stone">
                  <span>Subtotal</span>
                  <span className="tnum text-ink">{inr(subtotal)}</span>
                </div>
                <div className="flex justify-between text-sm text-stone">
                  <span>Shipping</span>
                  <span className="tnum text-ink">{shipping === 0 ? "Free" : inr(shipping)}</span>
                </div>
                <div className="flex items-baseline justify-between border-t border-ink/15 pt-4">
                  <span className="label text-ink">Payable</span>
                  <span className="tnum display text-3xl text-ink">{inr(total)}</span>
                </div>
              </div>
            </div>

            {method === "upi" && (
              <div className="mt-8 border border-brass/45 bg-ink-3 p-8 text-center">
                <p className="label text-brass-2">FORM &amp; FIELD · UPI ticket</p>
                <p className="tnum display mt-4 text-5xl text-paper">{inr(total)}</p>
                <p className="label mt-3 text-paper/55">
                  Payable now · order total
                </p>
                <div className="mt-7 flex justify-center">
                  <UpiQr amount={total} note={note} size={196} />
                </div>
                <p className="mt-6 text-xs leading-relaxed text-paper/60">
                  Scan with GPay, PhonePe, Paytm or BHIM. After paying, place the order — we match
                  the UPI reference against your order code and confirm it within a few hours.
                </p>
              </div>
            )}
          </div>
        </aside>
      </div>
    </div>
  );
}
