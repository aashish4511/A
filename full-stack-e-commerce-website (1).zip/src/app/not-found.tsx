import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto flex min-h-[62vh] max-w-[1400px] flex-col justify-center px-6 py-24 lg:px-12">
      <p className="label text-brass">Error 404</p>
      <h1 className="display mt-6 max-w-[16ch] text-[clamp(2.6rem,7vw,5.4rem)] text-ink">
        This piece has
        <span className="font-light italic text-stone"> left the shelf.</span>
      </h1>
      <p className="mt-8 max-w-[52ch] text-[17px] leading-[1.8] text-stone">
        The page you were looking for is not in the catalogue — it may have sold out, or the link may
        be mistyped. Everything currently on the shelf is one click away.
      </p>
      <div className="mt-10 flex flex-wrap gap-4">
        <Link
          href="/shop"
          className="label bg-ink px-8 py-4 text-paper transition-colors hover:bg-brass hover:text-ink-3"
        >
          Browse the catalogue
        </Link>
        <Link
          href="/"
          className="label border border-ink/25 px-8 py-4 text-ink transition-colors hover:border-brass hover:text-brass"
        >
          Back to home
        </Link>
      </div>
    </div>
  );
}
