import type { Metadata } from "next";
import "./globals.css";
import { CartProvider, VisitTracker } from "@/components/cart";
import { Footer, Header, Spine } from "@/components/ui";

export const metadata: Metadata = {
  title: "Form & Field — Watches, Fragrance & Everyday Wear",
  description:
    "A considered everyday edit of watches, perfumes, men's wear and women's wear. Shop across India with Cash on Delivery and UPI.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <base href="/" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700&family=Fraunces:ital,opsz,wght@0,9..144,300..900;1,9..144,300..900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="grain min-h-screen antialiased">
        <CartProvider>
          <VisitTracker />
          <Spine />
          <div className="lg:pl-16">
            <Header />
            <main>{children}</main>
            <Footer />
          </div>
        </CartProvider>
      </body>
    </html>
  );
}
