import Link from "next/link";
import { notFound } from "next/navigation";
import { getProductBySlug, listProducts } from "@/lib/store";
import { Reveal, Rule, ProductCard } from "@/components/ui";
import { BuyBox } from "@/components/buybox";
import { inr } from "@/lib/format";
import { Truck, QrCode, RotateCcw, Sparkles } from "lucide-react";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const p = await getProductBySlug(slug);
  if (!p) return { title: "Product not found — Form & Field" };
  return {
    title: `${p.name} — Form & Field`,
    description: p.tagline || p.description.slice(0, 150),
  };
}

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) notFound();

  const all = await listProducts();
  const related = all.filter((p) => p.id !== product.id && p.category === product.category).slice(0, 3);
  const more = related.length ? related : all.filter((p) => p.id !== product.id).slice(0, 3);
  const off = product.mrp > product.price ? Math.round((1 - product.price / product.mrp) * 100) : 0;
  const categoryHref = `/shop?category=${encodeURIComponent(product.category)}`;

  return (
    <div className="mx-auto max-w-[1400px] px-6 pb-24 pt-10 lg:px-12 lg:pt-14">
      <nav className="label flex flex-wrap items-center gap-2 text-stone">
        <Link href="/" className="hover:text-brass">Home</Link>
        <span>/</span>
        <Link href="/shop" className="hover:text-brass">Shop</Link>
        <span>/</span>
        <Link href={categoryHref} className="hover:text-brass">{product.category}</Link>
        <span>/</span>
        <span className="text-ink">{product.name}</span>
      </nav>

      <div className="mt-10 grid gap-12 lg:grid-cols-[minmax(0,1.05fr)_minmax(0,0.95fr)]">
        <Reveal className="relative">
          <div className="sweep relative aspect-[4/5] overflow-hidden bg-ink">
            <img src={product.image} alt={product.name} className="h-full w-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-ink/35 via-transparent to-transparent" />
          </div>
          <div className="mt-5 grid grid-cols-3 gap-4">
            {[
              ["Collection", product.category],
              ["Details", product.craft.split("·")[0]?.trim() || "Thoughtfully selected"],
              ["Availability", product.stock > 0 ? `${product.stock} in stock` : "Sold out"],
            ].map(([k, v]) => (
              <div key={k} className="border-t border-ink/15 pt-3">
                <p className="label text-stone">{k}</p>
                <p className="mt-1.5 text-sm text-ink">{v}</p>
              </div>
            ))}
          </div>
        </Reveal>

        <div className="lg:pt-4">
          <Reveal>
            <p className="label text-brass">
              {product.category} · {product.stock > 0 ? "In stock" : "Sold out"}
            </p>
            <h1 className="display mt-5 text-[clamp(2.3rem,5.6vw,4rem)] text-ink">{product.name}</h1>
            <p className="display mt-4 text-xl font-light italic text-stone">{product.tagline}</p>
          </Reveal>

          <Reveal delay={100}>
            <div className="mt-8 flex items-end gap-4">
              <p className="tnum display text-[2.6rem] leading-none text-ink">{inr(product.price)}</p>
              {product.mrp > product.price && (
                <>
                  <p className="tnum text-lg text-stone line-through">{inr(product.mrp)}</p>
                  <p className="label bg-vermillion px-3 py-1.5 text-paper">{off}% off</p>
                </>
              )}
            </div>
            <p className="mt-2 text-sm text-stone">Inclusive of all taxes. Ships in 2–4 working days.</p>
          </Reveal>

          <Reveal delay={160}>
            <div className="mt-8">
              <BuyBox product={product} />
            </div>
          </Reveal>

          <Reveal delay={220}>
            <div className="mt-10">
              <Rule />
              <p className="mt-8 text-[16px] leading-[1.85] text-stone">{product.description}</p>
            </div>
          </Reveal>

          <Reveal delay={280}>
            <div className="mt-10 space-y-6">
              <div className="flex gap-4">
                <Sparkles className="mt-0.5 h-5 w-5 shrink-0 text-brass" strokeWidth={1.5} />
                <div>
                  <p className="label text-ink">Specifications</p>
                  <p className="mt-2 text-sm leading-relaxed text-stone">{product.craft}</p>
                </div>
              </div>
              <div className="flex gap-4">
                <RotateCcw className="mt-0.5 h-5 w-5 shrink-0 text-brass" strokeWidth={1.5} />
                <div>
                  <p className="label text-ink">Care</p>
                  <p className="mt-2 text-sm leading-relaxed text-stone">{product.care}</p>
                </div>
              </div>
              <div className="flex gap-4">
                <Truck className="mt-0.5 h-5 w-5 shrink-0 text-brass" strokeWidth={1.5} />
                <div>
                  <p className="label text-ink">Shipping &amp; payment</p>
                  <p className="mt-2 text-sm leading-relaxed text-stone">
                    Free shipping above ₹2,500. Cash on Delivery available, or pay by UPI QR at checkout.
                  </p>
                </div>
              </div>
              <div className="flex gap-4">
                <QrCode className="mt-0.5 h-5 w-5 shrink-0 text-brass" strokeWidth={1.5} />
                <div>
                  <p className="label text-ink">UPI accepted</p>
                  <p className="tnum mt-2 text-sm leading-relaxed text-stone">9067794355@fam</p>
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </div>

      {more.length > 0 && (
        <section className="mt-28">
          <Reveal>
            <h2 className="display text-[clamp(1.8rem,3.6vw,2.6rem)] text-ink">More from the collection</h2>
          </Reveal>
          <div className="mt-10 grid gap-x-8 gap-y-16 sm:grid-cols-2 lg:grid-cols-3">
            {more.map((p, i) => (
              <ProductCard key={p.id} index={i} product={p} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
