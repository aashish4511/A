import Link from "next/link";
import { listProducts } from "@/lib/store";
import { ProductCard, Reveal, Rule } from "@/components/ui";
import { inr } from "@/lib/format";
import { ArrowRight, Truck, Clock3, Shirt, Sparkles } from "lucide-react";

export const dynamic = "force-dynamic";

const CATEGORIES = [
  {
    name: "Watches",
    note: "Time, considered.",
    image:
      "https://images.pexels.com/photos/11607481/pexels-photo-11607481.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  },
  {
    name: "Perfumes",
    note: "A scent that stays with you.",
    image: "/images/perfume.jpg",
  },
  {
    name: "Men's Wear",
    note: "Good layers, every day.",
    image:
      "https://images.pexels.com/photos/27584193/pexels-photo-27584193.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  },
  {
    name: "Women's Wear",
    note: "Made for your point of view.",
    image:
      "https://images.pexels.com/photos/19220820/pexels-photo-19220820.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  },
];

export default async function HomePage() {
  const all = await listProducts();
  const featured = all.filter((p) => p.featured).slice(0, 6);
  const fromPrice = all.length ? Math.min(...all.map((p) => p.price)) : 0;

  return (
    <>
      {/* ---------- HERO ---------- */}
      <section className="relative overflow-hidden">
        <div className="mx-auto max-w-[1400px] px-6 pb-20 pt-14 lg:px-12 lg:pb-28 lg:pt-20">
          <div className="grid items-center gap-10 lg:grid-cols-[minmax(0,1.02fr)_minmax(0,1fr)]">
            <div className="relative z-10">
              <Reveal>
                <p className="label text-brass">FORM &amp; FIELD · THE EVERYDAY EDIT</p>
              </Reveal>
              <Reveal delay={90}>
                <h1 className="display mt-6 text-[clamp(2.9rem,8.2vw,6.6rem)] font-semibold text-ink">
                  A little less
                  <br />
                  ordinary.
                  <br />
                  <span className="font-light italic text-brass">Every day.</span>
                </h1>
              </Reveal>
              <Reveal delay={180}>
                <div className="mt-8 h-px w-full max-w-[520px] origin-left bg-ink/25">
                  <div className="drawline is-in h-px w-full bg-brass/70" />
                </div>
              </Reveal>
              <Reveal delay={240}>
                <p className="mt-8 max-w-[46ch] text-[17px] leading-[1.75] text-stone">
                  Watches with a point of view. Fragrance that leaves a trace. Clothes you reach
                  for on repeat. A considered edit for every side of you.
                </p>
              </Reveal>
              <Reveal delay={300}>
                <div className="mt-10 flex flex-wrap items-center gap-4">
                  <Link
                    href="/shop"
                    className="group inline-flex items-center gap-3 bg-ink px-8 py-4 text-paper transition-colors hover:bg-brass hover:text-ink-3"
                  >
                    <span className="label">Shop the collection</span>
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </Link>
                  <Link
                    href="/#the-edit"
                    className="label border-b border-ink/30 pb-1 text-ink/80 transition-colors hover:border-brass hover:text-brass"
                  >
                    Discover the edit
                  </Link>
                </div>
              </Reveal>
              <Reveal delay={360}>
                <p className="tnum label mt-10 text-stone">
                  {all.length} considered finds · from {inr(fromPrice)} · COD &amp; UPI
                </p>
              </Reveal>
            </div>

            <Reveal delay={120} className="relative lg:-ml-16">
              <div className="sweep relative aspect-[4/5] overflow-hidden bg-ink lg:aspect-[5/6]">
                <img
                  src="/images/new-hero.jpg"
                  alt="A sculptural watch, amber fragrance and soft neutral textiles"
                  className="h-full w-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink/65 via-ink/5 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <p className="label text-paper/70">The new-season edit</p>
                  <p className="display mt-1.5 text-2xl text-paper">Time. Scent. Style.</p>
                </div>
              </div>
              <div className="absolute -bottom-6 -left-6 hidden bg-brass px-6 py-5 text-ink-3 shadow-[0_20px_50px_-28px_rgba(11,20,40,0.9)] lg:block">
                <p className="label">Thoughtful by design</p>
                <p className="display mt-1 text-xl">Made for the everyday</p>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* ---------- SERVICE STRIP ---------- */}
      <section className="border-y border-ink/12 bg-paper-2/60">
        <div className="mx-auto grid max-w-[1400px] grid-cols-2 gap-x-8 gap-y-6 px-6 py-8 lg:grid-cols-4 lg:px-12">
          {[
            { icon: Clock3, t: "Time, well spent", s: "Watches for every day" },
            { icon: Sparkles, t: "Scent, remembered", s: "Find your signature" },
            { icon: Shirt, t: "A better rotation", s: "Men's & women's wear" },
            { icon: Truck, t: "Delivered with care", s: "COD & UPI available" },
          ].map((f) => (
            <div key={f.t} className="flex items-start gap-3">
              <f.icon className="mt-0.5 h-5 w-5 shrink-0 text-brass" strokeWidth={1.5} />
              <div>
                <p className="label text-ink">{f.t}</p>
                <p className="tnum mt-1 text-sm text-stone">{f.s}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ---------- CATEGORIES ---------- */}
      <section className="mx-auto max-w-[1400px] px-6 pt-24 lg:px-12">
        <Reveal>
          <div className="flex flex-wrap items-end justify-between gap-6">
            <div>
              <p className="label text-brass">Find your thing</p>
              <h2 className="display mt-4 text-[clamp(2.2rem,5vw,3.9rem)] text-ink">
                Four ways to
                <span className="font-light italic text-stone"> make it yours.</span>
              </h2>
            </div>
            <Link
              href="/shop"
              className="label border-b border-ink/30 pb-1 text-ink/80 hover:border-brass hover:text-brass"
            >
              Browse everything →
            </Link>
          </div>
        </Reveal>
        <Reveal delay={120}>
          <div className="mt-10">
            <Rule />
          </div>
        </Reveal>
        <div className="mt-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {CATEGORIES.map((c, i) => (
            <Reveal key={c.name} delay={i * 90} className="group">
              <Link href={`/shop?category=${encodeURIComponent(c.name)}`} className="block">
                <div className="sweep relative aspect-[3/4] overflow-hidden bg-ink">
                  <img
                    src={c.image}
                    alt={c.name}
                    className="h-full w-full object-cover opacity-95 transition-transform duration-[900ms] group-hover:scale-105"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink-3/85 via-ink-3/15 to-transparent" />
                  <div className="absolute bottom-0 p-5">
                    <p className="display text-2xl text-paper">{c.name}</p>
                    <p className="label mt-2 text-paper/65">{c.note}</p>
                  </div>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ---------- FEATURED ---------- */}
      <section className="mx-auto max-w-[1400px] px-6 pt-24 lg:px-12">
        <Reveal>
          <div className="flex flex-wrap items-baseline justify-between gap-4">
            <h2 className="display text-[clamp(2rem,4.4vw,3.2rem)] text-ink">
              The pieces on our shortlist
            </h2>
            <p className="label text-stone">A good place to start</p>
          </div>
        </Reveal>
        <div className="mt-12 grid gap-x-8 gap-y-16 sm:grid-cols-2 lg:grid-cols-3">
          {featured.map((p, i) => (
            <ProductCard key={p.id} index={i} product={p} />
          ))}
        </div>
      </section>

      {/* ---------- THE EDIT ---------- */}
      <section id="the-edit" className="relative mt-28 overflow-hidden bg-ink-3">
        <img
          src="https://images.pexels.com/photos/19220820/pexels-photo-19220820.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1600&w=1200"
          alt="Contemporary fashion, styled for everyday wear"
          className="absolute inset-0 h-full w-full object-cover object-center opacity-50"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-ink-3 via-ink-3/85 to-ink-3/25" />
        <div className="relative mx-auto max-w-[1400px] px-6 py-24 lg:px-12 lg:py-32">
          <div className="max-w-[620px]">
            <Reveal>
              <p className="label text-brass-2">The edit · thoughtfully chosen</p>
            </Reveal>
            <Reveal delay={90}>
              <h2 className="display mt-6 text-[clamp(2.3rem,5.6vw,4.4rem)] leading-[1.02] text-paper">
                The pieces you wear on repeat,
                <span className="font-light italic text-brass-2"> start here.</span>
              </h2>
            </Reveal>
            <Reveal delay={180}>
              <p className="mt-8 text-[17px] leading-[1.8] text-paper/72">
                We look for the things that feel right the moment you put them on: considered
                silhouettes, wearable fabrics, a watch with a little character, a fragrance that
                feels like yours. The things that become part of your day before you know it.
              </p>
            </Reveal>
            <Reveal delay={260}>
              <p className="mt-6 text-[17px] leading-[1.8] text-paper/72">
                Pick a new favourite, build a better rotation, and make ordinary days feel a little
                more like your own.
              </p>
            </Reveal>
            <Reveal delay={330}>
              <Link
                href="/shop?category=Women's%20Wear"
                className="label mt-10 inline-flex items-center gap-3 border border-brass-2 px-8 py-4 text-brass-2 transition-colors hover:bg-brass-2 hover:text-ink-3"
              >
                Explore the edit <ArrowRight className="h-4 w-4" />
              </Link>
            </Reveal>
          </div>
        </div>
      </section>

      {/* ---------- PAYMENT BAND ---------- */}
      <section className="mx-auto max-w-[1400px] px-6 pt-24 lg:px-12">
        <div className="grid gap-12 border border-ink/15 bg-paper-2/50 p-8 lg:grid-cols-[1.15fr_1fr] lg:p-14">
          <div>
            <p className="label text-brass">Checkout, your way</p>
            <h2 className="display mt-5 text-[clamp(2rem,4.4vw,3.1rem)] text-ink">
              Cash when it arrives,
              <span className="font-light italic text-stone"> or scan to pay.</span>
            </h2>
            <p className="mt-6 max-w-[52ch] text-[16px] leading-[1.8] text-stone">
              Choose Cash on Delivery and pay the courier when your order reaches you. Prefer to pay
              now? We generate a UPI QR for your exact order total at{" "}
              <span className="tnum font-semibold text-ink">9067794355@fam</span> — scan with GPay,
              PhonePe, Paytm or any BHIM app.
            </p>
            <Link
              href="/shop"
              className="label mt-8 inline-flex items-center gap-3 bg-ink px-8 py-4 text-paper transition-colors hover:bg-brass hover:text-ink-3"
            >
              Find something good <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="flex items-center justify-center">
            <div className="relative w-full max-w-[360px] border border-brass/45 bg-paper p-7">
              <div className="perf absolute -left-[6px] top-0 h-full w-3" aria-hidden />
              <div className="perf absolute -right-[6px] top-0 h-full w-3" aria-hidden />
              <p className="label text-stone">Payment ticket</p>
              <p className="tnum display mt-3 text-5xl text-ink">₹0.00</p>
              <div className="mt-6 space-y-3">
                {[
                  ["Method", "Cash on Delivery / UPI"],
                  ["UPI handle", "9067794355@fam"],
                  ["Shipping", "Free above ₹2,500"],
                  ["Confirmation", "Order reference immediately"],
                ].map(([k, v]) => (
                  <div key={k} className="flex items-baseline justify-between gap-4 border-b border-ink/12 pb-2">
                    <span className="label text-stone">{k}</span>
                    <span className="tnum text-sm text-ink">{v}</span>
                  </div>
                ))}
              </div>
              <p className="label mt-6 text-brass">Scan · Pay · Done</p>
            </div>
          </div>
        </div>
      </section>

      {/* ---------- CLOSING ---------- */}
      <section className="mx-auto max-w-[1400px] px-6 pb-24 pt-24 lg:px-12">
        <Reveal>
          <p className="display max-w-[24ch] text-[clamp(2.2rem,5.6vw,4.2rem)] leading-[1.05] text-ink">
            <span className="font-light italic text-brass">&ldquo;</span>A good outfit begins with
            the pieces you reach for without thinking.
            <span className="font-light italic text-brass">&rdquo;</span>
          </p>
          <p className="label mt-8 text-stone">FORM &amp; FIELD · THE EVERYDAY EDIT</p>
        </Reveal>
      </section>
    </>
  );
}
