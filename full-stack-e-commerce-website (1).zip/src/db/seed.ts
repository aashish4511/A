import { db } from "@/db";
import { products } from "@/db/schema";
import { inArray } from "drizzle-orm";

export const CATEGORIES = ["Watches", "Perfumes", "Men's Wear", "Women's Wear"] as const;

export const SEED = [
  {
    slug: "noir-automatic-watch",
    name: "Noir Automatic Watch",
    tagline: "A considered silhouette. An automatic heart.",
    description:
      "A stainless-steel automatic watch with a deep black dial, exhibition caseback and a softly brushed bracelet. Built to move between a weekday desk and a late dinner without asking for attention.",
    craft: "316L stainless steel case · Automatic Japanese movement · 40 mm dial · Sapphire-coated glass",
    care: "Keep away from strong magnets. Wipe with a soft dry cloth. Not designed for swimming or showering.",
    category: "Watches",
    image:
      "https://images.pexels.com/photos/11607481/pexels-photo-11607481.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    price: 8490,
    mrp: 10990,
    stock: 8,
    featured: true,
  },
  {
    slug: "heritage-gold-chronograph",
    name: "Heritage Gold Chronograph",
    tagline: "A little ceremony, built into every hour.",
    description:
      "A polished gold-tone chronograph with a charcoal face, three subdials and a supple black strap. A precise everyday companion with a quieter, vintage-leaning profile.",
    craft: "Surgical steel case · Quartz chronograph movement · 42 mm dial · 5 ATM splash resistance",
    care: "Avoid prolonged exposure to water, perfume and household chemicals. Store flat when not worn.",
    category: "Watches",
    image:
      "https://images.pexels.com/photos/10414974/pexels-photo-10414974.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    price: 6250,
    mrp: 7990,
    stock: 11,
    featured: true,
  },
  {
    slug: "amber-no-03-eau-de-parfum",
    name: "Amber No. 03 Eau de Parfum",
    tagline: "Warm amber, soft woods, a trace of jasmine.",
    description:
      "A close-wearing, quietly sensual fragrance that opens with bergamot before settling into amber, cedar and jasmine. Made for the hours after sunset, and the memory that lingers after.",
    craft: "50 ml · Eau de parfum · Vegan formula · Made in India · No animal testing",
    care: "For external use only. Apply to pulse points. Keep away from direct sunlight and heat.",
    category: "Perfumes",
    image: "/images/perfume.jpg",
    price: 2450,
    mrp: 3200,
    stock: 16,
    featured: true,
  },
  {
    slug: "smoke-and-saffron-parfum",
    name: "Smoke & Saffron Parfum",
    tagline: "Saffron up top. Skin-close woods at the finish.",
    description:
      "A richer, more atmospheric parfum: bright saffron and cardamom meet a smoky heart of vetiver, then soften into sandalwood and warm skin. Concentrated, distinctive and never loud.",
    craft: "50 ml · Parfum concentration · Saffron, vetiver & sandalwood · Vegan formula",
    care: "Spray on pulse points from a short distance. Do not rub after application. Store cool and dry.",
    category: "Perfumes",
    image:
      "https://images.pexels.com/photos/38893412/pexels-photo-38893412.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    price: 2890,
    mrp: 3600,
    stock: 13,
    featured: true,
  },
  {
    slug: "weekend-linen-shirt",
    name: "Weekend Linen Shirt",
    tagline: "Easy through the shoulders. Better with every wash.",
    description:
      "A relaxed, long-sleeved linen-cotton shirt with a clean band collar and naturally breathable hand-feel. Cut to be worn open over a tee or buttoned up for plans that run into the evening.",
    craft: "55% European flax linen · 45% cotton · Relaxed fit · Natural shell buttons · Sizes S–XXL",
    care: "Machine wash cold with like colours. Line dry in shade. A light iron while slightly damp brings back the crisp finish.",
    category: "Men's Wear",
    image:
      "https://images.pexels.com/photos/27584193/pexels-photo-27584193.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    price: 2490,
    mrp: 3190,
    stock: 21,
    featured: true,
  },
  {
    slug: "city-light-overshirt",
    name: "City Light Overshirt",
    tagline: "A layer for the in-between weather.",
    description:
      "A soft-structured overshirt in a mid-weight cotton twill, finished with two chest pockets and tonal buttons. Wear it as a light jacket or as a shirt; the straight hem keeps both options easy.",
    craft: "100% BCI cotton twill · Easy straight fit · Two patch pockets · Sizes S–XXL",
    care: "Turn inside out and machine wash cold. Do not tumble dry. Steam on a low setting if needed.",
    category: "Men's Wear",
    image:
      "https://images.pexels.com/photos/31526073/pexels-photo-31526073.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    price: 3290,
    mrp: 4290,
    stock: 14,
    featured: true,
  },
  {
    slug: "soft-form-knit-dress",
    name: "Soft Form Knit Dress",
    tagline: "A clean line, a soft landing.",
    description:
      "A long-sleeved knit dress with a thoughtful, easy drape and a softly defined waist. Designed to move through a full day in comfort, with enough polish to carry straight into the evening.",
    craft: "Cotton-modal knit · Midi length · Soft stretch · Sizes XS–XXL",
    care: "Hand wash cool or use a delicate machine cycle inside a wash bag. Dry flat to keep its shape.",
    category: "Women's Wear",
    image:
      "https://images.pexels.com/photos/19220820/pexels-photo-19220820.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    price: 3790,
    mrp: 4690,
    stock: 12,
    featured: true,
  },
  {
    slug: "evening-edit-tailored-coord",
    name: "Evening Edit Co-ord",
    tagline: "Two pieces, a dozen ways to wear them.",
    description:
      "A relaxed tailored co-ord with a clean-lined jacket and an easy, fluid trouser. Made to be worn together or split into the pieces you'll reach for all week.",
    craft: "Viscose-linen blend · Fully lined jacket · Side pockets · Sizes XS–XXL",
    care: "Dry clean recommended. Steam gently on the reverse side. Hang the jacket between wears.",
    category: "Women's Wear",
    image:
      "https://images.pexels.com/photos/23911233/pexels-photo-23911233.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    price: 4890,
    mrp: 5990,
    stock: 9,
    featured: true,
  },
];

const LEGACY_SLUGS = [
  "brass-samai-diya",
  "kamal-urli",
  "terracotta-surahi",
  "hand-beaten-copper-bottle",
  "kansa-thali-set",
  "brass-hasti-door-handle",
];

export async function ensureSeeded() {
  const rows = await db.select({ id: products.id, slug: products.slug }).from(products);
  if (rows.length === 0) {
    await db.insert(products).values(SEED);
    return;
  }
  const legacy = rows.filter((r) => LEGACY_SLUGS.includes(r.slug)).map((r) => r.id);
  if (legacy.length > 0 && legacy.length === rows.length) {
    await db.delete(products).where(inArray(products.id, legacy));
    await db.insert(products).values(SEED);
  }
}
