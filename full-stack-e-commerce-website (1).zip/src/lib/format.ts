export const inr = (amount: number) =>
  "₹" + new Intl.NumberFormat("en-IN", { maximumFractionDigits: 0 }).format(amount || 0);

export const inrPlain = (amount: number) =>
  new Intl.NumberFormat("en-IN", { maximumFractionDigits: 0 }).format(amount || 0);

export const UPI_ID = "9067794355@fam";
export const UPI_PAYEE = "Form and Field";

export function upiUri(amount: number, note: string) {
  const params = new URLSearchParams({
    pa: UPI_ID,
    pn: UPI_PAYEE,
    am: (amount || 0).toFixed(2),
    cu: "INR",
    tn: note,
  });
  return `upi://pay?${params.toString()}`;
}

export function orderCode() {
  const n = Math.floor(1000 + Math.random() * 9000);
  return `PC-${new Date().getFullYear().toString().slice(2)}${(new Date().getMonth() + 1)
    .toString()
    .padStart(2, "0")}-${n}`;
}

export const dateLabel = (d: Date | string) =>
  new Date(d).toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
