"use client";

/**
 * Client-side session helper.
 *
 * The httpOnly cookie is the normal path. For embedded previews that block it,
 * keep the signed token in localStorage/sessionStorage and send x-admin-token.
 * If the browser blocks both storage APIs, leave the one-time token hand-off in
 * the address bar so a refresh cannot silently drop the admin session.
 */
const KEY = "pc_admin_token";
let memoryToken = "";

/** Store a session token; report whether either browser storage accepted it. */
export function saveToken(token: string): boolean {
  memoryToken = token;
  if (typeof window === "undefined") return false;
  let persisted = false;
  try {
    localStorage.setItem(KEY, token);
    persisted = true;
  } catch {
    /* localStorage may be blocked in embedded previews */
  }
  try {
    sessionStorage.setItem(KEY, token);
    persisted = true;
  } catch {
    /* sessionStorage may be blocked too */
  }
  return persisted;
}

export function readToken(): string {
  if (typeof window === "undefined") return "";
  if (memoryToken) return memoryToken;

  try {
    const stored = localStorage.getItem(KEY);
    if (stored) return (memoryToken = stored);
  } catch {
    /* ignore */
  }
  try {
    const stored = sessionStorage.getItem(KEY);
    if (stored) return (memoryToken = stored);
  } catch {
    /* ignore */
  }
  const mirror = document.cookie.match(/(?:^|;\s*)pc_admin_client=([^;]+)/);
  if (mirror) return (memoryToken = decodeURIComponent(mirror[1]));

  const fromUrl = new URLSearchParams(window.location.search).get("t");
  if (fromUrl) {
    saveToken(fromUrl);
    return fromUrl;
  }
  return "";
}

/** Store a `?t=` hand-off; only remove it if browser storage succeeded. */
export function adoptUrlToken() {
  if (typeof window === "undefined") return;
  const url = new URL(window.location.href);
  const token = url.searchParams.get("t");
  if (!token) return;
  const persisted = saveToken(token);
  if (!persisted) return;
  url.searchParams.delete("t");
  window.history.replaceState({}, "", url.pathname + (url.search || "") + url.hash);
}

export function clearToken() {
  memoryToken = "";
  if (typeof window === "undefined") return;
  try {
    localStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
  try {
    sessionStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
  document.cookie = "pc_admin_client=; Path=/; Max-Age=0; SameSite=None; Secure";
}

export function authHeaders(): HeadersInit {
  const token = readToken();
  return token ? { "x-admin-token": token } : {};
}

export async function adminFetch(path: string, init: RequestInit = {}) {
  const headers = new Headers(init.headers);
  if (!headers.has("Content-Type") && init.body) headers.set("Content-Type", "application/json");
  for (const [k, v] of new Headers(authHeaders()).entries()) headers.set(k, v);
  return fetch(path, { ...init, headers, credentials: "include" });
}
