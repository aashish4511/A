/**
 * Supabase connection (PostgREST / Data API).
 *
 * The project is `jsxdkiziznpaidqkuyid`. Credentials come from .env when present
 * (SUPABASE_URL / SUPABASE_PUBLISHABLE_KEY / SUPABASE_SECRET_KEY) and fall back to
 * the publishable key supplied by the shop owner. Publishable keys are designed to
 * be public; keep any `sb_secret_` key server-side only.
 */
export const SUPABASE_URL =
  process.env.SUPABASE_URL || "https://jsxdkiziznpaidqkuyid.supabase.co";
export const SUPABASE_KEY =
  process.env.SUPABASE_SECRET_KEY ||
  process.env.SUPABASE_PUBLISHABLE_KEY ||
  "sb_publishable_u1TtB-E-oqGIbq_BGfEeuw_n4IlhnAF";

export const SUPABASE_REF = SUPABASE_URL.replace("https://", "").split(".")[0];

export type SbRow = Record<string, unknown>;

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${SUPABASE_URL}/rest/v1${path}`, {
    ...init,
    cache: "no-store",
    headers: {
      apikey: SUPABASE_KEY,
      Authorization: `Bearer ${SUPABASE_KEY}`,
      "Content-Type": "application/json",
      ...(init?.headers || {}),
    },
  });
  const text = await res.text();
  let data: unknown = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = text;
  }
  if (!res.ok) {
    const err = data as { message?: string; code?: string };
    const message = err?.message || `Supabase responded ${res.status}`;
    const error = new Error(message) as Error & { code?: string };
    error.code = err?.code;
    throw error;
  }
  return data as T;
}

export const sbSelect = <T>(table: string, query: string) =>
  request<T[]>(`/${table}?${query}`);

export const sbInsert = <T>(table: string, rows: unknown) =>
  request<T[]>(`/${table}`, {
    method: "POST",
    headers: { Prefer: "return=representation" },
    body: JSON.stringify(rows),
  });

export const sbUpdate = <T>(table: string, filter: string, patch: unknown) =>
  request<T[]>(`/${table}?${filter}`, {
    method: "PATCH",
    headers: { Prefer: "return=representation" },
    body: JSON.stringify(patch),
  });

export const sbDelete = (table: string, filter: string) =>
  request<SbRow[]>(`/${table}?${filter}`, { method: "DELETE" });

/**
 * Detect which column shape a table uses. PostgREST rejects an unknown column in
 * `select=`, which makes this a reliable probe. Your Supabase project currently uses
 * the "shop" shape (order_number / customer_name / image_url …), while the schema in
 * supabase/schema.sql uses the "pc" shape (code / name / image …) — both are supported.
 */
export type Variant = "shop" | "pc";

export async function sbHasColumn(table: string, column: string): Promise<boolean> {
  try {
    await request<SbRow[]>(`/${table}?select=${column}&limit=1`);
    return true;
  } catch {
    return false;
  }
}

let variantCache: { value: Variant; at: number } | null = null;

export async function sbVariant(): Promise<Variant> {
  if (variantCache && Date.now() - variantCache.at < 60_000) return variantCache.value;
  const value: Variant = (await sbHasColumn("orders", "order_number")) ? "shop" : "pc";
  variantCache = { value, at: Date.now() };
  return value;
}

/** Exact row count via PostgREST content-range (HEAD request). */
export async function sbCount(table: string, filter = ""): Promise<number> {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}?${filter}`, {
    method: "HEAD",
    cache: "no-store",
    headers: {
      apikey: SUPABASE_KEY,
      Authorization: `Bearer ${SUPABASE_KEY}`,
      Prefer: "count=exact",
    },
  });
  const range = res.headers.get("content-range") || "";
  const total = Number(range.split("/")[1] ?? NaN);
  return Number.isFinite(total) ? total : 0;
}

/* ---- liveness probe (cached for 45s) ---- */

let probeAt = 0;
let probeResult: { ok: boolean; message: string } = { ok: false, message: "not probed yet" };

export async function supabaseStatus(): Promise<{ ok: boolean; message: string }> {
  if (Date.now() - probeAt < 45_000 && probeAt !== 0) return probeResult;
  probeAt = Date.now();
  try {
    await sbSelect<SbRow>("products", "select=id&limit=1");
    probeResult = { ok: true, message: "Connected — tables found" };
  } catch (e) {
    const message = e instanceof Error ? e.message : "unknown error";
    probeResult = {
      ok: false,
      message: /could not find the table/i.test(message)
        ? "Reachable, but the tables are missing — run supabase/schema.sql in the SQL editor"
        : message,
    };
  }
  return probeResult;
}

export async function supabaseReady(): Promise<boolean> {
  return (await supabaseStatus()).ok;
}

/** Raw probe used by the admin panel and /api/health. */
export async function supabaseDiagnostics() {
  const status = await supabaseStatus();
  return {
    url: SUPABASE_URL,
    ref: SUPABASE_REF,
    keyType: SUPABASE_KEY.startsWith("sb_secret_") ? "secret (service role)" : "publishable (anon)",
    ...status,
  };
}
