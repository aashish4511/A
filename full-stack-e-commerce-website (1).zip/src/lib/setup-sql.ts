/**
 * Shown in the admin "Data & Supabase" panel.
 *
 * Your Supabase project already contains `products`, `orders` and `order_items`
 * (the "shop" schema), so the store layer reads and writes those directly. The only
 * table missing is the visitor log — run this once in the SQL editor.
 */
export const SETUP_SQL = `-- Form & Field · add the visitor log (project jsxdkiziznpaidqkuyid)
-- products / orders / order_items already exist in your project — this only
-- adds the table that records every visit to the shop.

create table if not exists public.visitors (
  id         integer generated always as identity primary key,
  session_id varchar(64) not null default '',
  path       text not null default '/',
  referrer   text not null default '',
  user_agent text not null default '',
  created_at timestamptz not null default now()
);

create index if not exists visitors_created_at_idx on public.visitors (created_at desc);

alter table public.visitors enable row level security;

drop policy if exists "shop visitors" on public.visitors;
create policy "shop visitors" on public.visitors
  for all to anon using (true) with check (true);

-- optional sanity check
select count(*) as orders_now from public.orders;`;
