/**
 * Single data layer for the shop.
 *
 * Reads and writes go to **Supabase** whenever the project answers. Two column shapes
 * are supported: the "shop" shape already live in your Supabase project
 * (order_number / customer_name / image_url / items_json …) and the "pc" shape from
 * supabase/schema.sql (code / name / image …). If Supabase is unreachable every call
 * transparently falls back to the bundled PostgreSQL database so no order is lost.
 */
import { db } from "@/db";
import { orderItems, orders, products, visitors } from "@/db/schema";
import { ensureSeeded, SEED } from "@/db/seed";
import { desc, eq, sql } from "drizzle-orm";
import {
  sbCount,
  sbDelete,
  sbInsert,
  sbSelect,
  sbUpdate,
  sbVariant,
  supabaseDiagnostics,
  supabaseReady,
  type Variant,
} from "@/lib/supabase";
import { orderCode, UPI_ID, upiUri } from "@/lib/format";
import type { Order, OrderItem, Product } from "@/db/schema";

export type OrderWithItems = Order & { items: OrderItem[] };
export type VisitorRow = {
  id: number;
  sessionId: string;
  path: string;
  referrer: string;
  userAgent: string;
  createdAt: Date;
};

export type NewOrderInput = {
  name: string;
  phone: string;
  email: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  paymentMethod: string;
  paymentRef: string;
  note: string;
  items: { id: number; qty: number; variant?: string }[];
};

export type ProductInput = Partial<Product> & { name: string };

type Row = Record<string, unknown>;

const num = (v: unknown) => (typeof v === "number" ? v : Number(v) || 0);
const str = (v: unknown) => (typeof v === "string" ? v : v == null ? "" : String(v));
const when = (v: unknown) => (v instanceof Date ? v : new Date(str(v) || Date.now()));
const bool = (v: unknown) => v === true || v === "true" || v === 1;

const STATUS_MAP: Record<string, string> = {
  pending: "pending",
  confirmed: "confirmed",
  processing: "confirmed",
  shipped: "shipped",
  delivered: "delivered",
  rejected: "rejected",
  cancelled: "rejected",
  canceled: "rejected",
};
const readStatus = (v: unknown) => STATUS_MAP[str(v).toLowerCase()] || "pending";
const writeStatus = (status: string, variant: Variant) =>
  variant === "shop" ? status.toUpperCase() : status;

/* ---------------- products: description packing for the shop shape -------------- */

function packDescription(p: Partial<Product>) {
  const parts = [str(p.description)];
  if (p.tagline) parts.push(`[tagline] ${str(p.tagline)}`);
  if (p.craft) parts.push(`[craft] ${str(p.craft)}`);
  if (p.care) parts.push(`[care] ${str(p.care)}`);
  return parts.join("\n\n");
}

function unpackDescription(raw: string) {
  const grab = (tag: string) => {
    const m = raw.match(new RegExp(`\\n\\n\\[${tag}\\] ([\\s\\S]*?)(?=\\n\\n\\[|$)`));
    return m ? m[1].trim() : "";
  };
  return {
    description: raw.split("\n\n[")[0].trim(),
    tagline: grab("tagline"),
    craft: grab("craft"),
    care: grab("care"),
  };
}

function mapProduct(r: Row): Product {
  const shop = "image_url" in r;
  const packed = shop ? unpackDescription(str(r.description)) : null;
  return {
    id: num(r.id),
    slug: str(r.slug),
    name: str(r.name),
    tagline: packed ? packed.tagline : str(r.tagline),
    description: packed ? packed.description : str(r.description),
    craft: packed ? packed.craft : str(r.craft),
    care: packed ? packed.care : str(r.care),
    category: str(r.category) || "Watches",
    image: shop ? str(r.image_url) || "/images/new-hero.jpg" : str(r.image) || "/images/new-hero.jpg",
    price: num(r.price),
    mrp: num(shop ? r.original_price : r.mrp),
    stock: num(r.stock),
    featured: bool(shop ? r.is_featured : r.featured),
    createdAt: when(r.created_at ?? r.createdAt),
  };
}

function productPayload(p: ProductInput, variant: Variant) {
  const base = {
    slug: str(p.slug) || str(p.name).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, ""),
    name: str(p.name),
    category: str(p.category) || "Watches",
    price: num(p.price),
    stock: num(p.stock),
    description: variant === "shop" ? packDescription(p) : str(p.description),
    featured: Boolean(p.featured),
    mrp: num(p.mrp),
    image: str(p.image) || "/images/new-hero.jpg",
  };
  if (variant === "shop") {
    return {
      slug: base.slug,
      name: base.name,
      category: base.category,
      price: base.price,
      stock: base.stock,
      description: base.description,
      original_price: base.mrp,
      image_url: base.image,
      is_featured: base.featured,
      is_active: true,
    };
  }
  return {
    slug: base.slug,
    name: base.name,
    category: base.category,
    price: base.price,
    stock: base.stock,
    description: base.description,
    tagline: str(p.tagline),
    craft: str(p.craft),
    care: str(p.care),
    mrp: base.mrp,
    image: base.image,
    featured: base.featured,
  };
}

/* ---------------- orders mapping -------------- */

type Line = {
  productId: number;
  name: string;
  image: string;
  price: number;
  qty: number;
};

function mapOrder(r: Row): Order {
  const shop = "order_number" in r;
  return {
    id: num(r.id),
    code: shop ? str(r.order_number) : str(r.code),
    name: shop ? str(r.customer_name) : str(r.name),
    phone: shop ? str(r.customer_phone) : str(r.phone),
    email: shop ? str(r.customer_email) : str(r.email),
    address: shop ? str(r.shipping_address) : str(r.address),
    city: str(r.city),
    state: str(r.state),
    pincode: str(r.pincode),
    paymentMethod:
      (shop ? str(r.payment_method).toLowerCase() : str(r.payment_method)) === "upi" ? "upi" : "cod",
    paymentRef: shop ? str(r.upi_reference) : str(r.payment_ref),
    note: shop ? str(r.admin_note) : str(r.note),
    subtotal: num(r.subtotal),
    shipping: num(shop ? r.shipping_fee : r.shipping),
    total: num(shop ? r.total_amount : r.total),
    status: readStatus(r.status),
    createdAt: when(r.created_at ?? r.createdAt),
  };
}

function mapItem(r: Row): OrderItem {
  const shop = "product_name" in r;
  return {
    id: num(r.id),
    orderId: num(r.order_id ?? r.orderId),
    productId: shop ? num(r.product_id) : num(r.product_id ?? r.productId),
    name: shop ? str(r.product_name) : str(r.name),
    image: shop ? str(r.product_image) : str(r.image),
    price: num(shop ? r.unit_price : r.price),
    qty: num(shop ? r.quantity : r.qty) || 1,
  };
}

function mapVisitor(r: Row): VisitorRow {
  return {
    id: num(r.id),
    sessionId: str(r.session_id ?? r.sessionId),
    path: str(r.path),
    referrer: str(r.referrer),
    userAgent: str(r.user_agent ?? r.userAgent),
    createdAt: when(r.created_at ?? r.createdAt),
  };
}

/* ------------------------------------------------------------------ */
/* products                                                            */
/* ------------------------------------------------------------------ */

let seedTried = false;

export async function listProducts(): Promise<Product[]> {
  if (await supabaseReady()) {
    try {
      const variant = await sbVariant();
      const query =
        variant === "shop"
          ? "select=*&is_active=eq.true&order=id.asc"
          : "select=*&order=id.asc";
      let rows = (await sbSelect<Row>("products", query)).map(mapProduct);
      if (rows.length === 0 && !seedTried) {
        seedTried = true;
        const payloads = SEED.map((s) =>
          productPayload(s as unknown as ProductInput, variant),
        );
        rows = (await sbInsert<Row>("products", payloads)).map(mapProduct);
      }
      return rows.filter((p) => p.name !== "");
    } catch (e) {
      console.warn("[store] supabase listProducts failed, using postgres:", e);
    }
  }
  await ensureSeeded();
  return db.select().from(products).orderBy(products.id);
}

export async function getProductBySlug(slug: string): Promise<Product | null> {
  const all = await listProducts();
  return all.find((p) => p.slug === slug) ?? null;
}

export async function getProductById(id: number): Promise<Product | null> {
  const all = await listProducts();
  return all.find((p) => p.id === id) ?? null;
}

export async function saveProduct(input: ProductInput, id?: number) {
  if (await supabaseReady()) {
    try {
      const variant = await sbVariant();
      const payload = productPayload(input, variant);
      const rows = id
        ? await sbUpdate<Row>("products", `id=eq.${id}`, payload)
        : await sbInsert<Row>("products", payload);
      return rows.map(mapProduct)[0] ?? null;
    } catch (e) {
      console.warn("[store] supabase saveProduct failed, using postgres:", e);
    }
  }

  const payload = productPayload(input, "pc");
  if (id) {
    const [row] = await db.update(products).set(payload).where(eq(products.id, id)).returning();
    return row ?? null;
  }
  const [row] = await db.insert(products).values(payload as never).returning();
  return row ?? null;
}

export async function deleteProduct(id: number) {
  if (await supabaseReady()) {
    try {
      await sbDelete("products", `id=eq.${id}`);
      return;
    } catch (e) {
      console.warn("[store] supabase deleteProduct failed, using postgres:", e);
    }
  }
  await db.delete(products).where(eq(products.id, id));
}

/* ------------------------------------------------------------------ */
/* orders                                                              */
/* ------------------------------------------------------------------ */

function priceLines(catalog: Product[], items: { id: number; qty: number; variant?: string }[]) {
  const byId = new Map(catalog.map((p) => [p.id, p]));
  let subtotal = 0;
  const lines: Line[] = items
    .filter((i) => num(i.id) > 0)
    .map((it) => {
      const p = byId.get(num(it.id));
      const qty = Math.max(1, num(it.qty) || 1);
      const price = p?.price ?? 0;
      subtotal += price * qty;
      const variant = str(it.variant).trim();
      const name = `${p?.name ?? "Piece"}${variant ? ` · ${variant}` : ""}`;
      return { productId: p?.id ?? 0, name, image: p?.image ?? "", price, qty };
    });
  return { lines, subtotal, byId };
}

export async function createOrder(input: NewOrderInput) {
  const catalog = await listProducts();
  const { lines, subtotal, byId } = priceLines(catalog, input.items);
  const shipping = subtotal >= 2500 ? 0 : 149;
  const total = subtotal + shipping;
  const code = orderCode();
  const paymentMethod = input.paymentMethod === "upi" ? "upi" : "cod";
  const iso = new Date().toISOString();
  const clean = {
    name: str(input.name).slice(0, 120),
    phone: str(input.phone).slice(0, 20),
    email: str(input.email),
    address: str(input.address).slice(0, 400),
    city: str(input.city).slice(0, 80),
    state: str(input.state).slice(0, 80),
    pincode: str(input.pincode).slice(0, 10),
    note: str(input.note),
  };

  if (await supabaseReady()) {
    try {
      const variant = await sbVariant();
      const head =
        variant === "shop"
          ? {
              order_number: code,
              session_token: crypto.randomUUID(),
              customer_name: clean.name,
              customer_phone: clean.phone,
              customer_email: clean.email,
              shipping_address: clean.address,
              city: clean.city,
              state: clean.state,
              pincode: clean.pincode,
              payment_method: paymentMethod === "upi" ? "UPI" : "COD",
              upi_id: UPI_ID,
              upi_reference: clean.note || null,
              upi_uri: upiUri(total, `Order ${code}`),
              subtotal,
              shipping_fee: shipping,
              total_amount: total,
              status: "PENDING",
              admin_note: clean.note,
              items_json: lines.map((l) => ({
                product_id: l.productId,
                product_name: l.name,
                product_image: l.image,
                unit_price: l.price,
                quantity: l.qty,
                line_total: l.price * l.qty,
              })),
              created_at: iso,
              updated_at: iso,
            }
          : {
              code,
              name: clean.name,
              phone: clean.phone,
              email: clean.email,
              address: clean.address,
              city: clean.city,
              state: clean.state,
              pincode: clean.pincode,
              payment_method: paymentMethod,
              payment_ref: "",
              note: clean.note,
              subtotal,
              shipping,
              total,
              status: "pending",
            };

      const [order] = await sbInsert<Row>("orders", head);
      const orderId = num(order?.id ?? 0);

      if (lines.length && orderId) {
        const itemRows =
          variant === "shop"
            ? lines.map((l) => ({
                order_id: orderId,
                order_number: code,
                product_name: l.name,
                product_image: l.image,
                unit_price: l.price,
                quantity: l.qty,
                line_total: l.price * l.qty,
              }))
            : lines.map((l) => ({
                order_id: orderId,
                product_id: l.productId,
                name: l.name,
                image: l.image,
                price: l.price,
                qty: l.qty,
              }));
        await sbInsert("order_items", itemRows);
      }

      for (const l of lines) {
        if (!l.productId) continue;
        const p = byId.get(l.productId);
        await sbUpdate("products", `id=eq.${l.productId}`, {
          stock: Math.max(0, (p?.stock ?? 0) - l.qty),
        });
      }

      return { code, total, subtotal, shipping, paymentMethod, backend: "supabase" as const };
    } catch (e) {
      console.warn("[store] supabase createOrder failed, using postgres:", e);
    }
  }

  const [order] = await db
    .insert(orders)
    .values({
      code,
      name: clean.name,
      phone: clean.phone,
      email: clean.email,
      address: clean.address,
      city: clean.city,
      state: clean.state,
      pincode: clean.pincode,
      paymentMethod,
      paymentRef: "",
      note: clean.note,
      subtotal,
      shipping,
      total,
      status: "pending",
    })
    .returning();

  if (lines.length) {
    await db.insert(orderItems).values(lines.map((l) => ({ ...l, orderId: order.id })));
    for (const l of lines) {
      if (l.productId) {
        await db
          .update(products)
          .set({ stock: sql`greatest(${products.stock} - ${l.qty}, 0)` })
          .where(eq(products.id, l.productId));
      }
    }
  }
  return { code, total, subtotal, shipping, paymentMethod, backend: "postgres" as const };
}

export async function listOrders(): Promise<OrderWithItems[]> {
  if (await supabaseReady()) {
    try {
      const [oRows, iRows] = await Promise.all([
        sbSelect<Row>("orders", "select=*&order=created_at.desc"),
        sbSelect<Row>("order_items", "select=*&order=id.asc"),
      ]);
      const list = oRows.map(mapOrder);
      return list.map((o) => {
        const rawLines = iRows.filter(
          (r) => num(r.order_id ?? r.orderId) === o.id || str(r.order_number ?? r.orderNumber) === o.code,
        );
        const own = rawLines.map(mapItem);
        if (own.length > 0) return { ...o, items: own };

        // The shop schema also stores a durable product snapshot on the order itself.
        const raw = oRows.find((r) => num(r.id) === o.id);
        let snapshot: unknown = raw?.items_json ?? null;
        if (typeof snapshot === "string") {
          try {
            snapshot = JSON.parse(snapshot);
          } catch {
            snapshot = null;
          }
        }
        const lines = Array.isArray(snapshot) ? (snapshot as Row[]) : [];
        const fromJson = lines.map((line, idx) => ({
          id: num(line.id) || idx,
          orderId: o.id,
          productId: num(line.product_id ?? line.productId),
          name: str(line.product_name ?? line.name),
          image: str(line.product_image ?? line.image_url ?? line.image),
          price: num(line.unit_price ?? line.price),
          qty: num(line.quantity ?? line.qty) || 1,
        }));
        return { ...o, items: fromJson };
      });
    } catch (e) {
      console.warn("[store] supabase listOrders failed, using postgres:", e);
    }
  }
  const rows = await db.select().from(orders).orderBy(desc(orders.createdAt));
  const items = await db.select().from(orderItems);
  return rows.map((o) => ({ ...o, items: items.filter((i) => i.orderId === o.id) }));
}

export async function setOrderStatus(id: number, status: string): Promise<OrderWithItems | null> {
  if (await supabaseReady()) {
    try {
      const variant = await sbVariant();
      await sbUpdate("orders", `id=eq.${id}`, {
        status: writeStatus(status, variant),
        ...(variant === "shop" ? { updated_at: new Date().toISOString() } : {}),
      });
      return (await listOrders()).find((o) => o.id === id) ?? null;
    } catch (e) {
      console.warn("[store] supabase setOrderStatus failed, using postgres:", e);
    }
  }
  const [row] = await db.update(orders).set({ status }).where(eq(orders.id, id)).returning();
  if (!row) return null;
  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, id));
  return { ...row, items };
}

export async function getOrderByCode(code: string): Promise<OrderWithItems | null> {
  const all = await listOrders();
  return all.find((o) => o.code === code) ?? null;
}

/* ------------------------------------------------------------------ */
/* visitors                                                            */
/* ------------------------------------------------------------------ */

export async function logVisit(v: {
  sessionId: string;
  path: string;
  referrer: string;
  userAgent: string;
}) {
  const payload = {
    session_id: str(v.sessionId).slice(0, 64),
    path: str(v.path).slice(0, 200),
    referrer: str(v.referrer).slice(0, 300),
    user_agent: str(v.userAgent).slice(0, 300),
  };
  if (await supabaseReady()) {
    try {
      await sbInsert("visitors", payload);
      return;
    } catch (e) {
      console.warn("[store] supabase logVisit failed, using postgres:", e);
    }
  }
  await db.insert(visitors).values({
    sessionId: payload.session_id,
    path: payload.path,
    referrer: payload.referrer,
    userAgent: payload.user_agent,
  });
}

export async function listVisitors(): Promise<{ rows: VisitorRow[]; count: number }> {
  if (await supabaseReady()) {
    try {
      const rows = (
        await sbSelect<Row>("visitors", "select=*&order=created_at.desc&limit=40")
      ).map(mapVisitor);
      const count = await sbCount("visitors");
      return { rows, count };
    } catch (e) {
      console.warn("[store] supabase listVisitors failed, using postgres:", e);
    }
  }
  const rows = await db.select().from(visitors).orderBy(desc(visitors.createdAt)).limit(40);
  const [{ count }] = await db.select({ count: sql<number>`count(*)::int` }).from(visitors);
  return { rows: rows.map((r) => ({ ...r })), count: Number(count) || 0 };
}

/** Where the data is living right now — surfaced in the admin panel and /api/health. */
export async function dataStore() {
  const supabase = await supabaseDiagnostics();
  let variant: Variant | "unknown" = "unknown";
  if (supabase.ok) {
    try {
      variant = await sbVariant();
    } catch {
      variant = "unknown";
    }
  }
  return {
    backend: supabase.ok ? ("supabase" as const) : ("postgres" as const),
    schema: variant,
    supabase,
  };
}

/** One-time copy of local PostgreSQL data into Supabase (idempotent). */
export async function syncLocalToSupabase() {
  if (!(await supabaseReady())) {
    return {
      ok: false,
      message: "Supabase is not ready — check the connection first.",
      copied: null,
    };
  }
  const variant = await sbVariant();
  const [localProducts, localOrders, localItems, localVisitors] = await Promise.all([
    db.select().from(products),
    db.select().from(orders).orderBy(orders.id),
    db.select().from(orderItems),
    db.select().from(visitors),
  ]);

  const remoteProducts = await sbSelect<Row>("products", "select=slug");
  const haveSlug = new Set(remoteProducts.map((r) => str(r.slug)));
  let copiedProducts = 0;
  for (const row of localProducts) {
    if (haveSlug.has(row.slug)) continue;
    await sbInsert("products", productPayload(row as ProductInput, variant));
    copiedProducts += 1;
  }

  const remoteOrders = await sbSelect<Row>(
    "orders",
    variant === "shop" ? "select=order_number" : "select=code",
  );
  const haveCode = new Set(remoteOrders.map((r) => str(r.order_number ?? r.code)));
  let copiedOrders = 0;
  let copiedItems = 0;
  for (const row of localOrders) {
    if (haveCode.has(row.code)) continue;
    const lines = localItems
      .filter((i) => i.orderId === row.id)
      .map((l) => ({ productId: l.productId, name: l.name, image: l.image, price: l.price, qty: l.qty }));
    const [created] = await sbInsert<Row>("orders", {
      ...(variant === "shop"
        ? {
            order_number: row.code,
            session_token: crypto.randomUUID(),
            customer_name: row.name,
            customer_phone: row.phone,
            customer_email: row.email,
            shipping_address: row.address,
            payment_method: row.paymentMethod === "upi" ? "UPI" : "COD",
            upi_id: UPI_ID,
            upi_reference: row.paymentRef || null,
            upi_uri: upiUri(row.total, `Order ${row.code}`),
            shipping_fee: row.shipping,
            total_amount: row.total,
            status: writeStatus(row.status, "shop"),
            admin_note: row.note,
            items_json: lines.map((l) => ({
              product_id: l.productId,
              product_name: l.name,
              product_image: l.image,
              unit_price: l.price,
              quantity: l.qty,
              line_total: l.price * l.qty,
            })),
            updated_at: row.createdAt,
          }
        : {
            code: row.code,
            name: row.name,
            phone: row.phone,
            email: row.email,
            address: row.address,
            payment_method: row.paymentMethod,
            payment_ref: row.paymentRef,
            note: row.note,
            shipping: row.shipping,
            total: row.total,
            status: row.status,
          }),
      city: row.city,
      state: row.state,
      pincode: row.pincode,
      subtotal: row.subtotal,
      created_at: row.createdAt,
    });
    const orderId = num(created?.id ?? 0);
    if (lines.length && orderId) {
      await sbInsert(
        "order_items",
        variant === "shop"
          ? lines.map((l) => ({
              order_id: orderId,
              order_number: row.code,
              product_name: l.name,
              product_image: l.image,
              unit_price: l.price,
              quantity: l.qty,
              line_total: l.price * l.qty,
            }))
          : lines.map((l) => ({
              order_id: orderId,
              product_id: l.productId,
              name: l.name,
              image: l.image,
              price: l.price,
              qty: l.qty,
            })),
      );
      copiedItems += lines.length;
    }
    copiedOrders += 1;
  }

  let copiedVisitors = 0;
  try {
    const remoteVisitors = await sbCount("visitors");
    if (remoteVisitors === 0 && localVisitors.length) {
      await sbInsert(
        "visitors",
        localVisitors.map((v) => ({
          session_id: v.sessionId,
          path: v.path,
          referrer: v.referrer,
          user_agent: v.userAgent,
          created_at: v.createdAt,
        })),
      );
      copiedVisitors = localVisitors.length;
    }
  } catch {
    /* the visitors table may not exist in this schema — visits stay in PostgreSQL */
  }

  return {
    ok: true,
    message: "Local data copied into Supabase.",
    copied: { products: copiedProducts, orders: copiedOrders, items: copiedItems, visitors: copiedVisitors },
  };
}
