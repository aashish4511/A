import { createHmac, timingSafeEqual } from "crypto";
import type { NextRequest } from "next/server";

const SECRET = process.env.ADMIN_SESSION_SECRET || "peetal-clay-admin-secret";
export const ADMIN_USER = "admin";
export const ADMIN_PASS = "12345";
export const ADMIN_COOKIE = "pc_admin";

function sign(payload: string) {
  return createHmac("sha256", SECRET).update(payload).digest("hex").slice(0, 32);
}

export function issueToken() {
  const payload = `${ADMIN_USER}.${Date.now() + 1000 * 60 * 60 * 12}`;
  return `${payload}.${sign(payload)}`;
}

export function verifyToken(token?: string | null) {
  if (!token) return false;
  const parts = token.split(".");
  if (parts.length !== 3) return false;
  const [user, exp, sig] = parts;
  const expected = sign(`${user}.${exp}`);
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length) return false;
  if (!timingSafeEqual(a, b)) return false;
  if (Number(exp) < Date.now()) return false;
  return user === ADMIN_USER;
}

/**
 * Session lookup that works everywhere.
 *
 * The preview and any embedded iframe is a cross-site context, where browsers refuse
 * to store or send a `SameSite=Lax` cookie — and may block third-party cookies outright.
 * Prefer the fresh explicit header, then the URL hand-off, and only then cookies.
 * A stale cookie must never shadow a newly issued browser token.
 */
export function readAdminToken(req: NextRequest): string | null {
  return (
    req.headers.get("x-admin-token") ||
    req.nextUrl.searchParams.get("t") ||
    req.nextUrl.searchParams.get("token") ||
    req.cookies.get(ADMIN_COOKIE)?.value ||
    null
  );
}

export function isAdmin(req: NextRequest) {
  return verifyToken(readAdminToken(req));
}
