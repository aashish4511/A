-- ============================================================
--  Form & Field — Supabase schema for a fresh project
--  Existing Supabase projects with the shop column layout can use
--  the live Data API directly; this file is for a blank project.
-- ============================================================

create table if not exists public.products (
  id          integer generated always as identity primary key,
  slug        varchar(120) not null unique,
  name        text not null,
  tagline     text not null default '',
  description text not null default '',
  craft       text not null default '',
  care        text not null default '',
  category    varchar(60) not null default 'Watches',
  image       text not null default '/images/new-hero.jpg',
  price       integer not null default 0,
  mrp         integer not null default 0,
  stock       integer not null default 0,
  featured    boolean not null default false,
  created_at  timestamptz not null default now()
);

create table if not exists public.orders (
  id             integer generated always as identity primary key,
  code           varchar(24) not null unique,
  name           text not null,
  phone          varchar(20) not null,
  email          text not null default '',
  address        text not null,
  city           text not null,
  state          text not null,
  pincode        varchar(10) not null,
  payment_method varchar(10) not null default 'cod',
  payment_ref    text not null default '',
  note           text not null default '',
  subtotal       integer not null default 0,
  shipping       integer not null default 0,
  total          integer not null default 0,
  status         varchar(20) not null default 'pending',
  created_at     timestamptz not null default now()
);

create table if not exists public.order_items (
  id         integer generated always as identity primary key,
  order_id   integer not null references public.orders(id) on delete cascade,
  product_id integer not null default 0,
  name       text not null,
  image      text not null default '',
  price      integer not null default 0,
  qty        integer not null default 1
);

create table if not exists public.visitors (
  id         integer generated always as identity primary key,
  session_id varchar(64) not null default '',
  path       text not null default '/',
  referrer   text not null default '',
  user_agent text not null default '',
  created_at timestamptz not null default now()
);

create index if not exists orders_created_at_idx on public.orders (created_at desc);
create index if not exists orders_status_idx on public.orders (status);
create index if not exists order_items_order_id_idx on public.order_items (order_id);
create index if not exists products_category_idx on public.products (category);
create index if not exists visitors_created_at_idx on public.visitors (created_at desc);

alter table public.products     enable row level security;
alter table public.orders       enable row level security;
alter table public.order_items  enable row level security;
alter table public.visitors     enable row level security;

drop policy if exists "shop products" on public.products;
drop policy if exists "shop orders" on public.orders;
drop policy if exists "shop items" on public.order_items;
drop policy if exists "shop visitors" on public.visitors;

create policy "shop products" on public.products for all to anon using (true) with check (true);
create policy "shop orders" on public.orders for all to anon using (true) with check (true);
create policy "shop items" on public.order_items for all to anon using (true) with check (true);
create policy "shop visitors" on public.visitors for all to anon using (true) with check (true);

insert into public.products
  (slug, name, tagline, description, craft, care, category, image, price, mrp, stock, featured)
values
  ('noir-automatic-watch','Noir Automatic Watch','A considered silhouette. An automatic heart.','A stainless-steel automatic watch with a deep black dial, exhibition caseback and a softly brushed bracelet. Built for every day.','316L stainless steel case · Automatic Japanese movement · 40 mm dial · Sapphire-coated glass','Keep away from strong magnets. Wipe with a soft dry cloth.','Watches','https://images.pexels.com/photos/11607481/pexels-photo-11607481.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800',8490,10990,8,true),
  ('heritage-gold-chronograph','Heritage Gold Chronograph','A little ceremony, built into every hour.','A polished gold-tone chronograph with a charcoal face, three subdials and a supple black strap.','Surgical steel case · Quartz chronograph movement · 42 mm dial · 5 ATM splash resistance','Avoid prolonged exposure to water, perfume and household chemicals.','Watches','https://images.pexels.com/photos/10414974/pexels-photo-10414974.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800',6250,7990,11,true),
  ('amber-no-03-eau-de-parfum','Amber No. 03 Eau de Parfum','Warm amber, soft woods, a trace of jasmine.','A close-wearing fragrance that opens with bergamot before settling into amber, cedar and jasmine.','50 ml · Eau de parfum · Vegan formula · Made in India','For external use only. Apply to pulse points. Keep away from heat.','Perfumes','/images/perfume.jpg',2450,3200,16,true),
  ('smoke-and-saffron-parfum','Smoke & Saffron Parfum','Saffron up top. Skin-close woods at the finish.','A richer parfum of bright saffron and cardamom, smoky vetiver and warm sandalwood.','50 ml · Parfum concentration · Saffron, vetiver & sandalwood · Vegan formula','Spray on pulse points. Store cool and dry.','Perfumes','https://images.pexels.com/photos/38893412/pexels-photo-38893412.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800',2890,3600,13,true),
  ('weekend-linen-shirt','Weekend Linen Shirt','Easy through the shoulders. Better with every wash.','A relaxed linen-cotton shirt with a clean band collar and breathable hand-feel.','55% flax linen · 45% cotton · Relaxed fit · Sizes S–XXL','Machine wash cold with like colours. Line dry in shade.','Men''s Wear','https://images.pexels.com/photos/27584193/pexels-photo-27584193.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800',2490,3190,21,true),
  ('city-light-overshirt','City Light Overshirt','A layer for the in-between weather.','A soft-structured cotton twill overshirt with two chest pockets and tonal buttons.','100% BCI cotton twill · Easy straight fit · Sizes S–XXL','Turn inside out and machine wash cold. Do not tumble dry.','Men''s Wear','https://images.pexels.com/photos/31526073/pexels-photo-31526073.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800',3290,4290,14,true),
  ('soft-form-knit-dress','Soft Form Knit Dress','A clean line, a soft landing.','A long-sleeved knit dress with thoughtful drape and a softly defined waist.','Cotton-modal knit · Midi length · Soft stretch · Sizes XS–XXL','Hand wash cool or use a delicate cycle. Dry flat.','Women''s Wear','https://images.pexels.com/photos/19220820/pexels-photo-19220820.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800',3790,4690,12,true),
  ('evening-edit-tailored-coord','Evening Edit Co-ord','Two pieces, a dozen ways to wear them.','A relaxed tailored co-ord with a clean-lined jacket and fluid trouser, designed to work together or apart.','Viscose-linen blend · Fully lined jacket · Side pockets · Sizes XS–XXL','Dry clean recommended. Steam gently on the reverse side.','Women''s Wear','https://images.pexels.com/photos/23911233/pexels-photo-23911233.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800',4890,5990,9,true)
on conflict (slug) do nothing;
